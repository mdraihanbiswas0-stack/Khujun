# 🌟 Jonaki Search (জোনাকি সার্চ ও মোবাইল উইজেট)

**জোনাকি সার্চ** হলো একটি সর্বাধুনিক ও নান্দনিক ইউনিভার্সাল মোবাইল সার্চ ইঞ্জিন ও অ্যান্ড্রয়েড ক্রোম-স্টাইল উইজেট ইকোসিস্টেম। এতে রয়েছে অ্যানিমেটেড বায়োলুমিনেসেন্ট জোনাকি পোকা মাসকট, ১৫টি কাস্টমাইজেবল টুলস, এবং ফাইল, অ্যাপস, কন্টাক্ট, ইউটিউব, কুরআন ও জেমিনি এআই ভিত্তিক ধাপে ধাপে অনুসন্ধান সুবিধা।

---

## 🚀 প্রধান ফিচারসমূহ

1. **গুগল ক্রোম-স্টাইল স্লিম মোবাইল উইজেট**:
   - অতি স্লিম ও ১০০% ফ্রেমের ভেতরে সুরক্ষিত উইজেট বার (জিরো ওভারফ্লো)।
   - ১৫টি কার্যকর টুলস (ক্যামেরা, ভয়েস, ফাইল, অ্যাপস, কন্টাক্ট, ওয়েব, ইউটিউব, কুরআন, ক্যালকুলেটর ইত্যাদি)।
   - প্রতিটি টুলসের জন্য আলাদা কাস্টম রঙ ও ব্যাকগ্রাউন্ড সিলেকশন।
   - ডানে-বামে স্মুথ স্ক্রোলিং ও কাস্টমাইজেশন।

2. **বাস্তবধর্মী অ্যানিমেটেড জোনাকি পোকা (Jonaki Firefly Mascot)**:
   - প্রাকৃতিক শারীরিক গঠন, অবিরত ডানার ঝাপটানি (`fluttering wings`) ও শ্বাস-প্রশ্বাসের মতো উজ্জ্বল বায়োলুমিনেসেন্ট আলো।
   - ট্যাপ করলে মিষ্টি চাইম সাউন্ড, নিওন স্পার্কল ও বাংলায় বুদ্ধিমান টিপস/স্পিচ বাবল।

3. **ধাপে ধাপে সোর্স-ভিত্তিক ইউনিভার্সাল সার্চ (Stepped Search Engine)**:
   - **ধাপ ১: জোনাকি এআই অন্তর্দৃষ্টি**: জেমিনি ৩.৮ ফ্ল্যাশ দ্বারা তাৎক্ষণিক স্মার্ট সারাংশ ও তথ্য।
   - **ধাপ ২: মোবাইল ফাইল ও স্টোরেজ**: ফটো, ভিডিও, গান, ডকুমেন্টস এবং নিজের ফাইল আপলোড ও প্রিভিউ।
   - **ধাপ ৩: ইনস্টল করা অ্যাপস**: ফোনের বিকাশ, নগদ, ফেসবুক, ক্রোম ইত্যাদি অ্যাপস লঞ্চার।
   - **ধাপ ৪: ফোনবুক কন্টাক্ট**: ১-ক্লিকে কল, এসএমএস, হোয়াটসঅ্যাপ এবং নম্বর কপি।
   - **ধাপ ৫: ইউটিউব ভিডিও**: সরাসরি বাংলা ভিডিও সার্চ ও স্ট্রিমিং।
   - **ধাপ ৬: অনলাইন ও সোশ্যাল**: গুগল, ফেসবুক, টিকটক, উইকিপিডিয়া সার্চ।
   - **ধাপ ৭: কুরআন ও হাদিস**: সূরা, আয়াত, আরবি ও বাংলা অর্থসহ ইসলামিক রেফারেন্স।

4. **ভিজ্যুয়াল ক্যামেরা সার্চ ও QR স্ক্যানার**:
   - লাইভ ক্যামেরা দিয়ে ছবি তুলে বা গ্যালারি থেকে যেকোনো ছবি আপলোড করে জেমিনি এআই দিয়ে দৃশ্য ও লেখা (OCR) বিশ্লেষণ।

5. **অ্যান্ড্রয়েড APK ফরম্যাট ও PWA রেডি**:
   - ১-ক্লিকে অ্যান্ড্রয়েড ফোনে নেটিভ WebAPK ইনস্টলেশন।
   - PWABuilder / Capacitor দিয়ে অফলাইন `.apk` প্যাকেজ তৈরির পূর্ণ কনফিগারেশন।

---

## 🛠️ প্রযুক্তিগত কাঠামো (Tech Stack)

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Canvas Confetti
- **Backend**: Node.js, Express, tsx
- **AI Engine**: `@google/genai` (Gemini 3.8 Flash model)
- **PWA & Mobile**: `vite-plugin-pwa`, Web App Manifest, Service Worker
- **Build Tool**: Vite 8

---

## 💻 গিটহাব থেকে ক্লোন ও রান করার নিয়ম (Installation & Run)

### ১. রিপোজিটরি ক্লোন করুন
```bash
git clone https://github.com/YOUR_USERNAME/jonaki-search.git
cd jonaki-search
```

### ২. ডিপেন্ডেন্সি ইনস্টল করুন
```bash
npm install
```

### ৩. এনভায়রনমেন্ট ভেরিয়েবল সেট করুন
প্রজেক্টের রুট ফোল্ডারে একটি `.env` ফাইল তৈরি করুন:
```env
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
PORT=3000
```
*(গুগল এআই স্টুডিও বা Google AI MakerSuite থেকে বিনামূল্যে আপনার API Key সংগ্রহ করতে পারেন)*

### ৪. ডেভেলপমেন্ট সার্ভার চালু করুন
```bash
npm run dev
```
ব্রাউজারে `http://localhost:3000` লিঙ্কে প্রবেশ করুন।

### ৫. প্রোডাকশন বিল্ড ও রান
```bash
npm run build
npm start
```

---

## 📱 অ্যান্ড্রয়েড APK তৈরি করার নিয়ম (Generate Android APK)

### পদ্ধতি ১: PWABuilder দিয়ে ১-ক্লিকে APK (সবচেয়ে সহজ)
1. অ্যাপটি Vercel, Netlify, Render বা Cloud Run-এ ডিপ্লয় করুন।
2. [PWABuilder.com](https://www.pwabuilder.com/) ওয়েবসাইটে গিয়ে আপনার অ্যাপের লাইভ লিংক পেস্ট করুন।
3. **"Package for Android"** বাটনে চাপ দিয়ে সরাসরি রেডিমেড `jonaki-search.apk` ফাইল ডাউনলোড করে নিন।

### পদ্ধতি ২: Capacitor দিয়ে লোকাল APK বিল্ড
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Jonaki Search" "com.jonaki.search"
npm run build
npx cap add android
npx cap open android
```
এরপর Android Studio খুলে `Build > Build Bundle(s) / APK(s) > Build APK(s)` নির্বাচন করলেই আপনার কম্পিউটারে `.apk` ফাইল তৈরি হয়ে যাবে।

---

## 📁 গিটহাবে আপলোড করার কমান্ড (Push to GitHub)

```bash
git init
git add .
git commit -m "Initial release of Jonaki Search app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/jonaki-search.git
git push -u origin main
```

---

## 📄 লাইসেন্স
Apache-2.0 License

---

## 📲 নেটিভ অ্যান্ড্রয়েড অ্যাপ (ফোনের ভেতরের সব কিছু খোঁজা)

`native-android/` ফোল্ডারে Java প্লাগইন ও হোমস্ক্রিন সার্কেল উইজেট আছে।

```bash
bash native-android/setup.sh      # Capacitor + প্লাগইন + উইজেট বসায়
npx cap open android              # Android Studio-তে Run / Build APK
```

- AI সার্চের জন্য সার্ভার ডিপ্লয় করে `.env`-এ `VITE_API_BASE="https://your-server"` দিন, তারপর আবার `npm run build && npx cap sync android`।
- প্রথমবার অ্যাপ খুলে "অনুমতি দিন" এবং "সব ফাইলে অ্যাক্সেস" চালু করুন।
- Play Store-এর জন্য MANAGE_EXTERNAL_STORAGE-এর বিশেষ অনুমোদন লাগে; নিজে ইনস্টল করলে সমস্যা নেই।
