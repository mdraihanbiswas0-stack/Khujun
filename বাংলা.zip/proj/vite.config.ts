import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'icon.svg', 'apple-touch-icon.png'],
        manifest: {
          id: '/',
          name: 'Jonaki Search - জোনাকি সার্চ ও মোবাইল উইজেট',
          short_name: 'JonakiSearch',
          description: 'মোবাইলের ফাইল, ছবি, ভিডিও, অ্যাপস, কন্টাক্ট এবং ইন্টারনেট সার্চের সার্বজনীন উইজেট ও এআই সার্চ ইঞ্জিন',
          theme_color: '#090d16',
          background_color: '#090d16',
          display: 'standalone',
          orientation: 'portrait-primary',
          start_url: '/',
          scope: '/',
          categories: ['utilities', 'productivity', 'search'],
          shortcuts: [
            {
              name: 'Camera Search (ক্যামেরা)',
              short_name: 'Camera',
              description: 'ক্যামেরা ও QR কোড দিয়ে স্ক্যান করুন',
              url: '/?action=camera',
              icons: [{ src: '/icon.svg', sizes: '192x192' }],
            },
            {
              name: 'Voice Search (ভয়েস)',
              short_name: 'Voice',
              description: 'মুখে বলে যেকোনো কিছু খুঁজুন',
              url: '/?action=voice',
              icons: [{ src: '/icon.svg', sizes: '192x192' }],
            },
            {
              name: 'Device Files (ফাইল)',
              short_name: 'Files',
              description: 'মোবাইল ফাইল ও স্টোরেজ ব্রাউজার',
              url: '/?action=files',
              icons: [{ src: '/icon.svg', sizes: '192x192' }],
            },
          ],
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
