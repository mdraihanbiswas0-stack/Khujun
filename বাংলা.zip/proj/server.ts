import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Parse JSON bodies with up to 25MB for image uploads
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI SDK
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    name: 'Jonaki Search API',
  });
});

// Endpoint: Visual Search via Gemini Vision (analyzing camera photo or uploaded image)
app.post('/api/search/visual', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', prompt = 'এই ছবিটি বিশ্লেষণ করুন' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    if (!aiClient) {
      // Fallback response if API key is not configured
      return res.json({
        title: 'ছবি বিশ্লেষণ সম্পন্ন',
        description: 'ছবিটি সফলভাবে প্রসেস করা হয়েছে। স্থানীয় ভিজ্যুয়াল সার্চ ফলাফল নিচে প্রদর্শিত হলো।',
        tags: ['ক্যামেরা স্ন্যাপ', 'ছবি অনুসন্ধান', 'মোবাইল ফটো'],
        textDetected: 'ক্যামেরা ইনপুট শনাক্তকৃত',
        sourceCategory: 'visual',
        suggestedActions: [
          { label: 'গুগল লেন্সে দেখুন', url: `https://www.google.com/searchbyimage?image_url=` },
          { label: 'ইউটিউবে খুঁজুন', url: `https://www.youtube.com/results?search_query=Visual+Search` },
          { label: 'ডিভাইস ফাইলে খুঁজুন', action: 'files' },
        ],
      });
    }

    // Clean base64 string
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType,
            data: cleanBase64,
          },
        },
        {
          text: `You are 'Jonaki' (জোনাকি) - an intelligent visual search engine for a mobile user in Bangladesh.
Analyze this user image thoroughly.
Detect:
1. What is the subject / object / document / scene?
2. Any visible Bengali or English text (OCR)?
3. If it is a QR code or barcode or math problem or product or nature or invoice.
4. Provide structured analysis with a concise Bengali summary, search keywords, and relevant categories.

Format your response as valid JSON with keys:
{
  "title": "সংক্ষিপ্ত ও আকর্ষণীয় শিরোনাম (বাংলা)",
  "description": "বিস্তারিত ২-৩ বাক্যের ব্যাখ্যা (বাংলায়)",
  "category": "ডকুমেন্ট / পণ্য / উদ্ভিদ ও প্রকৃতি / প্রযুক্তি / স্থান / অন্যান্য",
  "tags": ["ট্যাগ১", "ট্যাগ২", "ট্যাগ৩"],
  "textDetected": "ছবিতে পাওয়া কোনো লেখা থাকলে তা উল্লেখ করুন (বা খালি রাখুন)",
  "searchKeywords": ["keyword 1", "keyword 2"],
  "actionSuggestions": [
    {"label": "ওয়েবে আরও জানুন", "query": "keyword"},
    {"label": "ইউটিউবে ভিডিও দেখুন", "query": "keyword"}
  ]
}
Return only pure JSON without markdown code fences.`,
        },
      ],
    });

    const rawText = response.text || '{}';
    let parsedData = {};
    try {
      const cleanJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleanJson);
    } catch {
      parsedData = {
        title: 'ছবি বিশ্লেষণ সমাপ্ত',
        description: rawText,
        tags: ['ভিজ্যুয়াল সার্চ', 'মোবাইল ছবি'],
      };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.error('Visual search error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to analyze image with visual AI',
      fallback: {
        title: 'ছবি প্রসেস করা হয়েছে',
        description: 'ছবির উপাদান শনাক্ত হয়েছে। আরও বিস্তারিত তথ্যের জন্য সার্চ বারে নাম লিখে খুঁজুন।',
      },
    });
  }
});

// Endpoint: AI Universal Smart Search (Deep answers, Quran insights, Web summary)
app.post('/api/search/ai', async (req, res) => {
  try {
    const { query, category = 'all' } = req.body;

    if (!query || typeof query !== 'string') {
      return res.status(400).json({ error: 'Query is required' });
    }

    if (!aiClient) {
      return res.json({
        summary: `"${query}" সংক্রান্ত অনুসন্ধান ফলাফল প্রস্তুত। আপনার মোবাইল স্টোরেজ ও ইন্টারনেট থেকে তথ্য সংগ্রহ করা হচ্ছে।`,
        keyFacts: [
          `সার্চ কিওয়ার্ড: ${query}`,
          `ক্যাটাগরি: ${category}`,
          `ডিভাইস এবং অনলাইন সোর্স সমন্বিত`,
        ],
        smartActions: [
          { label: 'গুগলে সার্চ', url: `https://www.google.com/search?q=${encodeURIComponent(query)}` },
          { label: 'ইউটিউবে দেখুন', url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}` },
        ],
      });
    }

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are 'Jonaki Search' (জোনাকি সার্চ) - an all-in-one universal mobile search engine helper.
The user is searching for: "${query}" (Requested category filter: "${category}").

Please provide:
1. A concise, accurate, and helpful 2-sentence Bengali answer/summary.
2. 3 bullet key facts or insights (in Bengali).
3. Suggested high-relevance search links for Google, YouTube, Facebook, and if religious/spiritual, Quran reference.
4. Suggested mobile device action (e.g. check files, contacts, or apps).

Output strictly valid JSON with this format:
{
  "summary": "বাংলায় ২ বাক্যে স্পষ্ট ও তথ্যবহুল উত্তর",
  "keyFacts": ["তথ্য ১", "তথ্য ২", "তথ্য ৩"],
  "relatedQueries": ["সম্পর্কিত অনুসন্ধান ১", "সম্পর্কিত অনুসন্ধান ২", "সম্পর্কিত অনুসন্ধান ৩"],
  "quranReference": "যদি বিষয়টি ইসলামিক বা আধ্যাত্মিক হয় তবে সূরা ও আয়াত নম্বর বা প্রাসঙ্গিক হাদিস (নতুবা null)",
  "recommendedSource": "ওয়েব / মোবাইল ফাইল / ইউটিউব / কুরআন / কন্টাক্ট"
}
Return only JSON.`,
    });

    const rawText = response.text || '{}';
    let parsedData = {};
    try {
      const cleanJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleanJson);
    } catch {
      parsedData = {
        summary: rawText,
        keyFacts: [`সার্চ কিওয়ার্ড: ${query}`],
      };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.error('AI Search error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to complete AI search',
    });
  }
});

// Mount Vite or serve static assets
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Jonaki Search server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
