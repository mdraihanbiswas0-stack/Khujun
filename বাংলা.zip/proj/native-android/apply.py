#!/usr/bin/env python3
"""Copies the native plugin + widget into the Capacitor android/ project and patches the manifest."""
import os, shutil, sys

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
app = os.path.join(root, 'android', 'app', 'src', 'main')
if not os.path.isdir(app):
    sys.exit('android/ ফোল্ডার নেই। আগে `npx cap add android` চালান।')

pkg_dir = os.path.join(app, 'java', 'com', 'jonaki', 'search')
os.makedirs(pkg_dir, exist_ok=True)
for f in os.listdir(os.path.join(root, 'native-android', 'java')):
    shutil.copy(os.path.join(root, 'native-android', 'java', f), pkg_dir)

for sub in ('layout', 'drawable', 'xml'):
    dst = os.path.join(app, 'res', sub)
    os.makedirs(dst, exist_ok=True)
    src = os.path.join(root, 'native-android', 'res', sub)
    for f in os.listdir(src):
        shutil.copy(os.path.join(src, f), dst)

mp = os.path.join(app, 'AndroidManifest.xml')
m = open(mp, encoding='utf-8').read()
if 'JonakiWidgetProvider' not in m:
    perms = '''
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
    </queries>
'''
    receiver = '''
        <receiver android:name=".JonakiWidgetProvider" android:exported="true" android:label="Jonaki Search">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/jonaki_widget_info" />
        </receiver>
'''
    m = m.replace('<application', perms + '\n    <application', 1)
    m = m.replace('</application>', receiver + '    </application>', 1)
    open(mp, 'w', encoding='utf-8').write(m)
print('✔ নেটিভ প্লাগইন, উইজেট ও পারমিশন যোগ হয়েছে')
