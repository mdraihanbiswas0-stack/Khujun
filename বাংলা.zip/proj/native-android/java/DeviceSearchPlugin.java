package com.jonaki.search;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@CapacitorPlugin(
    name = "DeviceSearch",
    permissions = {
        @Permission(alias = "contacts", strings = { Manifest.permission.READ_CONTACTS }),
        @Permission(alias = "images", strings = { "android.permission.READ_MEDIA_IMAGES" }),
        @Permission(alias = "videos", strings = { "android.permission.READ_MEDIA_VIDEO" }),
        @Permission(alias = "audio", strings = { "android.permission.READ_MEDIA_AUDIO" }),
        @Permission(alias = "legacy", strings = { Manifest.permission.READ_EXTERNAL_STORAGE })
    }
)
public class DeviceSearchPlugin extends Plugin {

    // ---------- Permissions ----------

    private boolean granted(String alias) {
        return getPermissionState(alias) == PermissionState.GRANTED;
    }

    private JSObject permissionStatus() {
        boolean media = Build.VERSION.SDK_INT >= 33
            ? (granted("images") && granted("videos") && granted("audio"))
            : granted("legacy");
        boolean allFiles = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager() : granted("legacy");
        JSObject o = new JSObject();
        o.put("contacts", granted("contacts"));
        o.put("media", media);
        o.put("allFiles", allFiles);
        return o;
    }

    @PluginMethod
    public void checkAll(PluginCall call) {
        call.resolve(permissionStatus());
    }

    @PluginMethod
    public void requestAll(PluginCall call) {
        String[] aliases = Build.VERSION.SDK_INT >= 33
            ? new String[] { "contacts", "images", "videos", "audio" }
            : new String[] { "contacts", "legacy" };
        requestPermissionForAliases(aliases, call, "permsDone");
    }

    @PermissionCallback
    private void permsDone(PluginCall call) {
        call.resolve(permissionStatus());
    }

    /** Opens the system "All files access" screen so documents, PDFs, downloads etc. become searchable. */
    @PluginMethod
    public void openAllFilesSettings(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName())
                );
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // ---------- Installed apps ----------

    @PluginMethod
    public void getApps(PluginCall call) {
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            Collections.sort(list, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo a, ResolveInfo b) {
                    return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
                }
            });
            JSArray arr = new JSArray();
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (!seen.add(pkg)) continue;
                JSObject o = new JSObject();
                o.put("name", ri.loadLabel(pm).toString());
                o.put("packageName", pkg);
                o.put("system", (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                try {
                    o.put("icon", iconData(ri.loadIcon(pm)));
                } catch (Exception ignored) {}
                arr.put(o);
            }
            JSObject res = new JSObject();
            res.put("apps", arr);
            call.resolve(res);
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    private String iconData(Drawable d) {
        int s = 64;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, s, s);
        d.draw(c);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, bos);
        return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    @PluginMethod
    public void launchApp(PluginCall call) {
        String pkg = call.getString("packageName");
        Intent i = pkg == null ? null : getContext().getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            call.reject("অ্যাপটি খোলা যায়নি");
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    // ---------- Contacts ----------

    @PluginMethod
    public void getContacts(PluginCall call) {
        if (!granted("contacts")) {
            call.reject("কন্টাক্ট পারমিশন দেওয়া হয়নি");
            return;
        }
        try {
            ContentResolver cr = getContext().getContentResolver();
            Map<String, JSObject> map = new LinkedHashMap<>();

            Cursor c = cr.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] {
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                },
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            );
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    String num = c.getString(2);
                    JSObject o = map.get(id);
                    if (o == null) {
                        o = new JSObject();
                        o.put("id", id);
                        o.put("name", name == null ? num : name);
                        o.put("phone", num);
                        map.put(id, o);
                    } else if (!o.has("secondaryPhone") && num != null && !num.equals(o.optString("phone"))) {
                        o.put("secondaryPhone", num);
                    }
                }
                c.close();
            }

            Cursor e = cr.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                new String[] {
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Email.ADDRESS
                },
                null, null, null
            );
            if (e != null) {
                while (e.moveToNext()) {
                    JSObject o = map.get(e.getString(0));
                    if (o != null && !o.has("email")) o.put("email", e.getString(1));
                }
                e.close();
            }

            JSArray arr = new JSArray();
            for (JSObject o : map.values()) arr.put(o);
            JSObject res = new JSObject();
            res.put("contacts", arr);
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(ex.getMessage());
        }
    }

    // ---------- Files, photos, videos, audio, documents ----------

    /**
     * Searches the device's MediaStore index by file name.
     * category: all | photo | video | audio | document
     */
    @PluginMethod
    public void searchFiles(PluginCall call) {
        String query = call.getString("query", "");
        String category = call.getString("category", "all");
        int limit = call.getInt("limit", 300);

        try {
            Uri uri = MediaStore.Files.getContentUri("external");
            String[] proj = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.DATA
            };

            StringBuilder sel = new StringBuilder("(" + MediaStore.Files.FileColumns.SIZE + " > 0 AND "
                + MediaStore.Files.FileColumns.MIME_TYPE + " IS NOT NULL)");
            java.util.ArrayList<String> args = new java.util.ArrayList<>();

            if (query != null && !query.trim().isEmpty()) {
                String q = query.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
                sel.append(" AND ").append(MediaStore.Files.FileColumns.DISPLAY_NAME).append(" LIKE ? ESCAPE '\\'");
                args.add("%" + q + "%");
            }
            int mt = -1;
            if ("photo".equals(category)) mt = MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
            else if ("video".equals(category)) mt = MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
            else if ("audio".equals(category)) mt = MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO;
            else if ("document".equals(category)) mt = MediaStore.Files.FileColumns.MEDIA_TYPE_NONE;
            if (mt >= 0) sel.append(" AND ").append(MediaStore.Files.FileColumns.MEDIA_TYPE).append(" = ").append(mt);

            String sort = MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC";
            ContentResolver cr = getContext().getContentResolver();
            Cursor c;
            if (Build.VERSION.SDK_INT >= 26) {
                Bundle b = new Bundle();
                b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel.toString());
                b.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toArray(new String[0]));
                b.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
                b.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
                c = cr.query(uri, proj, b, null);
            } else {
                c = cr.query(uri, proj, sel.toString(), args.toArray(new String[0]), sort + " LIMIT " + limit);
            }

            JSArray arr = new JSArray();
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    String name = c.getString(1);
                    String mime = c.getString(4);
                    int type = c.getInt(5);
                    String cat = "document";
                    if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE) cat = "photo";
                    else if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) cat = "video";
                    else if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO) cat = "audio";
                    else if (name != null && name.toLowerCase().endsWith(".apk")) cat = "apk";

                    JSObject o = new JSObject();
                    o.put("id", id);
                    o.put("name", name);
                    o.put("size", c.getLong(2));
                    o.put("updatedAt", c.getLong(3));
                    o.put("mime", mime);
                    o.put("category", cat);
                    o.put("path", c.getString(6));
                    o.put("uri", ContentUris.withAppendedId(uri, id).toString());
                    arr.put(o);
                }
                c.close();
            }
            JSObject res = new JSObject();
            res.put("files", arr);
            call.resolve(res);
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    @PluginMethod
    public void openFile(PluginCall call) {
        String path = call.getString("path");
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "*/*");
        try {
            Uri uri = null;
            if (path != null && new File(path).exists()) {
                uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", new File(path));
            } else if (uriStr != null) {
                uri = Uri.parse(uriStr);
            }
            if (uri == null) {
                call.reject("ফাইল পাওয়া যায়নি");
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            call.reject("এই ফাইল খোলার মতো অ্যাপ নেই");
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // ---------- Settings ----------

    @PluginMethod
    public void openSetting(PluginCall call) {
        String action = call.getString("action", Settings.ACTION_SETTINGS);
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Exception ignored) {}
        }
        call.resolve();
    }
}
