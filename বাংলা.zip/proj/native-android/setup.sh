#!/usr/bin/env bash
set -e
npm install
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npm run build
[ -d android ] || npx cap add android
python3 native-android/apply.py
npx cap sync android
echo "এখন চালান: npx cap open android  (তারপর Android Studio থেকে Run বা Build APK)"
