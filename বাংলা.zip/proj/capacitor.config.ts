const config = {
  appId: 'com.jonaki.search',
  appName: 'Jonaki Search',
  webDir: 'dist',
  android: { allowMixedContent: false },
};
export default config;
