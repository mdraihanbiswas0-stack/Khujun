import React, { useState, useEffect, useMemo } from 'react';
import {
  Smartphone,
  Search,
  Folder,
  Users,
  Palette,
  Sparkles,
  Layers,
  Settings,
  HelpCircle,
  ExternalLink,
  Sliders,
  CheckCircle2,
  Download,
} from 'lucide-react';
import {
  MobileFile,
  InstalledApp,
  ContactItem,
  QuranSurah,
  WidgetToolItem,
  WidgetStyleConfig,
  SearchCategory,
  AiSearchResult,
} from './types';
import {
  INITIAL_WIDGET_TOOLS,
  INITIAL_WIDGET_CONFIG,
  MOCK_MOBILE_FILES,
  MOCK_INSTALLED_APPS,
  MOCK_CONTACTS,
  POPULAR_QURAN_REFS,
} from './data/mockDeviceData';
import { JonakiFirefly } from './components/JonakiFirefly';
import { JonakiWidget } from './components/JonakiWidget';
import { UniversalSearchResults } from './components/UniversalSearchResults';
import { CameraSearchModal } from './components/CameraSearchModal';
import { VoiceSearchModal } from './components/VoiceSearchModal';
import { WidgetCustomizerModal } from './components/WidgetCustomizerModal';
import { DeviceFilesManagerModal } from './components/DeviceFilesManagerModal';
import { ContactsManagerModal } from './components/ContactsManagerModal';
import { CalculatorModal } from './components/CalculatorModal';
import { FilePreviewModal } from './components/FilePreviewModal';
import { MobileHomeScreenSimulator } from './components/MobileHomeScreenSimulator';
import { PermissionsQuickAccess } from './components/PermissionsQuickAccess';
import { FloatingMiniWidget } from './components/FloatingMiniWidget';
import { ApkExportModal } from './components/ApkExportModal';
import { openAndroidApp } from './utils/androidIntent';
import { useDeviceData } from './hooks/useDeviceData';
import { DevicePermissionBanner } from './components/DevicePermissionBanner';
import { DeviceSearch } from './plugins/deviceSearch';

export default function App() {
  // Navigation View: 'search' (Universal search engine) or 'homescreen' (Mobile home screen widget simulation)
  const [activeView, setActiveView] = useState<'search' | 'homescreen'>('search');

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<SearchCategory>('all');
  const [aiResult, setAiResult] = useState<AiSearchResult | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  // Widget Customization State
  const [tools, setTools] = useState<WidgetToolItem[]>(() => {
    const saved = localStorage.getItem('jonaki_tools_v2');
    return saved ? JSON.parse(saved) : INITIAL_WIDGET_TOOLS;
  });

  const [styleConfig, setStyleConfig] = useState<WidgetStyleConfig>(() => {
    const saved = localStorage.getItem('jonaki_style');
    return saved ? JSON.parse(saved) : INITIAL_WIDGET_CONFIG;
  });

  // Device Data State
  const [files, setFiles] = useState<MobileFile[]>(() => {
    const saved = localStorage.getItem('jonaki_files');
    return saved ? JSON.parse(saved) : MOCK_MOBILE_FILES;
  });

  const [contacts, setContacts] = useState<ContactItem[]>(() => {
    const saved = localStorage.getItem('jonaki_contacts');
    return saved ? JSON.parse(saved) : MOCK_CONTACTS;
  });

  // Real phone data (only on the installed Android app); browser keeps demo data
  const device = useDeviceData();
  const apps: InstalledApp[] = device.isNative ? device.apps : MOCK_INSTALLED_APPS;
  const [quranRefs] = useState<QuranSurah[]>(POPULAR_QURAN_REFS);

  // Modals Visibility
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [isFilesManagerOpen, setIsFilesManagerOpen] = useState(false);
  const [isContactsManagerOpen, setIsContactsManagerOpen] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [previewFile, setPreviewFile] = useState<MobileFile | null>(null);
  const [showFloatingWidget, setShowFloatingWidget] = useState(true);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Save customizations to local storage
  useEffect(() => {
    localStorage.setItem('jonaki_tools_v2', JSON.stringify(tools));
  }, [tools]);

  useEffect(() => {
    localStorage.setItem('jonaki_style', JSON.stringify(styleConfig));
  }, [styleConfig]);

  useEffect(() => {
    localStorage.setItem('jonaki_files', JSON.stringify(files));
  }, [files]);

  useEffect(() => {
    localStorage.setItem('jonaki_contacts', JSON.stringify(contacts));
  }, [contacts]);

  // Execute AI Search query when submitted
  const handlePerformSearch = async (query: string) => {
    if (!query.trim()) return;
    setIsLoadingAi(true);
    setAiResult(null);

    try {
      const res = await fetch(`${(import.meta as any).env?.VITE_API_BASE ?? ''}/api/search/ai`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, category: categoryFilter }),
      });
      const data = await res.json();
      setAiResult(data);
    } catch (err) {
      console.warn('AI search request failed, using local search fallback');
      setAiResult({
        summary: `"${query}" সংক্রান্ত অনুসন্ধান ফলাফল তৈরি সম্পন্ন। ডিভাইস ও অনলাইন থেকে প্রাসঙ্গিক তথ্য সাজানো হয়েছে।`,
        keyFacts: [`সার্চ কিওয়ার্ড: ${query}`, 'মোবাইল ফাইল ও কন্টাক্ট পর্যবেক্ষণ করা হয়েছে', 'অনলাইন সোর্স অন্তর্ভুক্ত'],
      });
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Perform AI search debounce when query changes
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery.trim().length >= 2) {
        handlePerformSearch(searchQuery);
      }
    }, 900);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const allFiles = device.isNative ? device.files : files;
  const allContacts = device.isNative ? [...device.contacts, ...contacts.filter((c) => c.id.startsWith('contact-'))] : contacts;

  // Native file search (debounced) over the whole phone
  useEffect(() => {
    if (!device.isNative) return;
    const id = setTimeout(() => device.searchFiles(searchQuery.trim()), 300);
    return () => clearTimeout(id);
  }, [searchQuery, device.isNative]);

  // Filtered files
  const filteredFiles = useMemo(() => {
    if (!searchQuery) return allFiles;
    const q = searchQuery.toLowerCase();
    return allFiles.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.path.toLowerCase().includes(q) ||
        f.tags.some((t) => t.toLowerCase().includes(q))
    );
  }, [allFiles, searchQuery]);

  // Filtered apps
  const filteredApps = useMemo(() => {
    if (!searchQuery) return apps;
    const q = searchQuery.toLowerCase();
    return apps.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.nameBn.includes(q) ||
        a.category.toLowerCase().includes(q)
    );
  }, [apps, searchQuery]);

  // Filtered contacts
  const filteredContacts = useMemo(() => {
    if (!searchQuery) return allContacts;
    const q = searchQuery.toLowerCase();
    return allContacts.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (c.relationship && c.relationship.toLowerCase().includes(q))
    );
  }, [allContacts, searchQuery]);

  // Filtered Quran References
  const filteredQuran = useMemo(() => {
    if (!searchQuery) return quranRefs;
    const q = searchQuery.toLowerCase();
    return quranRefs.filter(
      (s) =>
        s.nameBengali.toLowerCase().includes(q) ||
        s.nameArabic.includes(q) ||
        s.nameEnglish.toLowerCase().includes(q) ||
        s.meaning.toLowerCase().includes(q) ||
        (s.popularAyat && s.popularAyat.bengali.toLowerCase().includes(q))
    );
  }, [quranRefs, searchQuery]);

  // Handle Tool Click Actions
  const handleToolAction = (actionId: string) => {
    switch (actionId) {
      case 'camera':
      case 'gallery':
        setIsCameraOpen(true);
        break;
      case 'voice':
        setIsVoiceOpen(true);
        break;
      case 'files':
        setIsFilesManagerOpen(true);
        break;
      case 'contacts':
        setIsContactsManagerOpen(true);
        break;
      case 'settings':
        setCategoryFilter('settings');
        setActiveView('search');
        break;
      case 'apps':
        setCategoryFilter('apps');
        setActiveView('search');
        break;
      case 'chrome':
        setCategoryFilter('web');
        setActiveView('search');
        break;
      case 'youtube':
        setCategoryFilter('youtube');
        setActiveView('search');
        break;
      case 'quran':
        setCategoryFilter('quran');
        setActiveView('search');
        break;
      case 'calculator':
        setIsCalculatorOpen(true);
        break;
      case 'clipboard':
        navigator.clipboard.readText().then((text) => {
          if (text) {
            setSearchQuery(text);
            handlePerformSearch(text);
          }
        }).catch(() => {});
        break;
      case 'customizer':
        setIsCustomizerOpen(true);
        break;
      default:
        setActiveView('search');
        break;
    }
  };

  const handleLaunchApp = (app: InstalledApp) => {
    // On a real Android phone, launch the installed app by package name
    if (app.packageName && openAndroidApp(app.packageName)) return;
    if (app.launchUrl) {
      window.open(app.launchUrl, '_blank');
    } else {
      alert(`"${app.nameBn}" (${app.name}) অ্যাপটি চালু করা হয়েছে।`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-amber-400 selection:text-slate-950 font-['Hind_Siliguri',sans-serif]">
      {/* Top Bar Contract: Zone 1 (Wordmark) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Primary CTA) */}
      <header className="sticky top-0 z-40 w-full bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-8 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Single element brand wordmark */}
        <div className="flex items-center gap-2.5 shrink-0 select-none">
          <JonakiFirefly size="sm" showSpeechBubble={false} />
          <span className="text-base sm:text-lg font-extrabold tracking-tight text-white flex items-center gap-1.5 font-['Outfit']">
            <span>Jonaki</span>
            <span className="text-amber-400 font-bold font-['Hind_Siliguri']">সার্চ</span>
          </span>
        </div>

        {/* Zone 2: 4 Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-semibold text-slate-300">
          <button
            type="button"
            onClick={() => setActiveView('search')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeView === 'search' ? 'text-amber-400 font-bold' : ''
            }`}
          >
            সার্চ ড্যাশবোর্ড
          </button>
          <button
            type="button"
            onClick={() => setActiveView('homescreen')}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
              activeView === 'homescreen' ? 'text-amber-400 font-bold' : ''
            }`}
          >
            মোবাইল স্ক্রিন উইজেট
          </button>
          <button
            type="button"
            onClick={() => setIsFilesManagerOpen(true)}
            className="transition-colors whitespace-nowrap shrink-0 hover:text-white"
          >
            ফাইল ম্যানেজার
          </button>
          <button
            type="button"
            onClick={() => setIsContactsManagerOpen(true)}
            className="transition-colors whitespace-nowrap shrink-0 hover:text-white"
          >
            কন্টাক্ট ফোনবুক
          </button>
        </nav>

        {/* Zone 3: Primary Actions (ZIP Download, APK Export & Widget Customizer) */}
        <div className="flex items-center gap-2 shrink-0">
          <a
            href="/jonaki-search-app.zip"
            download="jonaki-search-app.zip"
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/40 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 whitespace-nowrap shrink-0"
            title="সম্পূর্ণ প্রজেক্ট ZIP ডাউনলোড (GitHub রেডি)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ZIP ডাউনলোড</span>
            <span className="sm:hidden">ZIP</span>
          </a>
          <button
            type="button"
            onClick={() => setIsApkModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 whitespace-nowrap shrink-0"
            title="অ্যান্ড্রয়েড APK ফরম্যাট ও ফোনে ইনস্টল"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>APK ফরম্যাট</span>
          </button>
          <button
            type="button"
            onClick={() => setIsCustomizerOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center gap-1.5 transition-all border border-amber-400/30 whitespace-nowrap shrink-0"
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">স্টাইলার</span>
          </button>
        </div>
      </header>

      {/* Main View Area */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-3 sm:px-6 py-6 space-y-6">
        {/* Top View Toggle Tab on Mobile */}
        <div className="flex md:hidden items-center justify-center p-1 rounded-2xl bg-slate-900 border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveView('search')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeView === 'search' ? 'bg-amber-400 text-slate-950 shadow-md' : 'text-slate-400'
            }`}
          >
            সার্চ ড্যাশবোর্ড
          </button>
          <button
            type="button"
            onClick={() => setActiveView('homescreen')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeView === 'homescreen' ? 'bg-amber-400 text-slate-950 shadow-md' : 'text-slate-400'
            }`}
          >
            মোবাইল স্ক্রিন উইজেট
          </button>
        </div>

        {activeView === 'search' ? (
          <>
            {/* The Google Chrome Style Search Widget with Jonaki Firefly */}
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>জোনাকি স্মার্ট মোবাইল উইজেট (Google Chrome স্টাইল)</span>
                </span>
                <span className="text-[11px] text-slate-500">
                  টুলস ডানে-বামে স্ক্রোল করুন
                </span>
              </div>

              <JonakiWidget
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                onSearchSubmit={handlePerformSearch}
                tools={tools}
                styleConfig={styleConfig}
                onToolClick={handleToolAction}
                onOpenCustomizer={() => setIsCustomizerOpen(true)}
                onOpenVoiceSearch={() => setIsVoiceOpen(true)}
                onOpenCameraSearch={() => setIsCameraOpen(true)}
              />
            </div>

            {/* Permissions & Quick Access Hub */}
            <PermissionsQuickAccess onQuickAction={handleToolAction} />

            {device.isNative && (
              <DevicePermissionBanner
                perm={device.perm}
                error={device.error}
                onGrant={device.grant}
                onGrantAllFiles={device.grantAllFiles}
              />
            )}

            {/* Stepped Universal Search Results */}
            <UniversalSearchResults
              query={searchQuery}
              categoryFilter={categoryFilter}
              onCategoryFilterChange={setCategoryFilter}
              files={filteredFiles}
              apps={filteredApps}
              contacts={filteredContacts}
              quranRefs={filteredQuran}
              aiResult={aiResult}
              isLoadingAi={isLoadingAi}
              onPreviewFile={(f) =>
                device.isNative && DeviceSearch && f.uri
                  ? DeviceSearch.openFile({ path: f.path, uri: f.uri, mime: f.mimeType }).catch(() => {})
                  : setPreviewFile(f)
              }
              onLaunchApp={handleLaunchApp}
            />
          </>
        ) : (
          /* Mobile Home Screen Widget Simulator */
          <MobileHomeScreenSimulator
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onSearchSubmit={handlePerformSearch}
            tools={tools}
            styleConfig={styleConfig}
            onToolClick={handleToolAction}
            onOpenCustomizer={() => setIsCustomizerOpen(true)}
            onOpenVoiceSearch={() => setIsVoiceOpen(true)}
            onOpenCameraSearch={() => setIsCameraOpen(true)}
            installedApps={apps}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}
      </main>

      {/* Floating Mini Widget (Always on screen as requested) */}
      <FloatingMiniWidget
        isVisible={showFloatingWidget}
        onClose={() => setShowFloatingWidget(false)}
        onSearch={(q) => {
          setSearchQuery(q);
          handlePerformSearch(q);
          setActiveView('search');
        }}
        onOpenCamera={() => setIsCameraOpen(true)}
        onOpenVoice={() => setIsVoiceOpen(true)}
      />

      {/* Android APK Format & Export Modal */}
      <ApkExportModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Camera, Gallery, QR & Visual AI Lens Modal */}
      <CameraSearchModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onApplySearchQuery={(q) => {
          setSearchQuery(q);
          handlePerformSearch(q);
          setActiveView('search');
        }}
      />

      {/* Voice Search Modal */}
      <VoiceSearchModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onApplyQuery={(q) => {
          setSearchQuery(q);
          handlePerformSearch(q);
          setActiveView('search');
        }}
      />

      {/* Widget Customizer Modal */}
      <WidgetCustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        tools={tools}
        onUpdateTools={setTools}
        styleConfig={styleConfig}
        onUpdateStyleConfig={setStyleConfig}
        onResetDefaults={() => {
          setTools(INITIAL_WIDGET_TOOLS);
          setStyleConfig(INITIAL_WIDGET_CONFIG);
        }}
      />

      {/* Device Files Manager Modal */}
      <DeviceFilesManagerModal
        isOpen={isFilesManagerOpen}
        onClose={() => setIsFilesManagerOpen(false)}
        files={files}
        onAddFiles={(newFiles) => setFiles((prev) => [...newFiles, ...prev])}
        onPreviewFile={setPreviewFile}
      />

      {/* Contacts Directory Modal */}
      <ContactsManagerModal
        isOpen={isContactsManagerOpen}
        onClose={() => setIsContactsManagerOpen(false)}
        contacts={contacts}
        onAddContact={(newContact) => setContacts((prev) => [newContact, ...prev])}
      />

      {/* Quick Calculator Modal */}
      <CalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
      />

      {/* File Preview Modal */}
      <FilePreviewModal
        file={previewFile}
        onClose={() => setPreviewFile(null)}
      />

      {/* Footer */}
      <footer className="w-full border-t border-slate-900 bg-slate-950 py-5 text-center text-xs text-slate-500">
        <div className="flex items-center justify-center gap-2 mb-1">
          <JonakiFirefly size="sm" showSpeechBubble={false} />
          <span className="font-semibold text-slate-400">জোনাকি ইউনিভার্সাল সার্চ ও মোবাইল উইজেট সিস্টেম</span>
        </div>
        <p className="text-[11px] text-slate-600">
          ডিভাইস ফাইল, অ্যাপস, কন্টাক্ট এবং ইন্টারনেট সার্চের সমন্বিত প্ল্যাটফর্ম
        </p>
      </footer>
    </div>
  );
}
