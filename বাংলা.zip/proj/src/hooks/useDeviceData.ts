import { useCallback, useEffect, useRef, useState } from 'react';
import { DeviceSearch, isNative, PermissionStatus } from '../plugins/deviceSearch';
import { ContactItem, InstalledApp, MobileFile } from '../types';

const COLORS = ['#2563eb', '#16a34a', '#db2777', '#7c3aed', '#d97706', '#0891b2', '#ea580c'];
const colorFor = (s: string) => COLORS[[...s].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length];

const fmtSize = (b: number) =>
  b > 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';

export function useDeviceData() {
  const [perm, setPerm] = useState<PermissionStatus | null>(null);
  const [apps, setApps] = useState<InstalledApp[]>([]);
  const [contacts, setContacts] = useState<ContactItem[]>([]);
  const [files, setFiles] = useState<MobileFile[]>([]);
  const [error, setError] = useState('');
  const lastQuery = useRef('');

  const loadFiles = useCallback(async (query = '') => {
    if (!DeviceSearch) return;
    lastQuery.current = query;
    try {
      const { files: list } = await DeviceSearch.searchFiles({ query, limit: query ? 500 : 200 });
      if (lastQuery.current !== query) return; // a newer search started
      setFiles(
        list.map((f) => ({
          id: `f${f.id}`,
          name: f.name,
          category: f.category,
          size: fmtSize(f.size),
          updatedAt: new Date(f.updatedAt * 1000).toLocaleDateString('bn-BD'),
          path: f.path || f.uri,
          mimeType: f.mime,
          uri: f.uri,
          tags: [],
        })),
      );
    } catch (e: any) {
      setError(String(e?.message || e));
    }
  }, []);

  const loadAll = useCallback(async () => {
    if (!DeviceSearch) return;
    try {
      const { apps: list } = await DeviceSearch.getApps();
      setApps(
        list.map((a) => ({
          id: `app_${a.packageName}`,
          name: a.name,
          nameBn: a.name,
          packageName: a.packageName,
          category: a.system ? 'system' : 'utility',
          icon: 'Smartphone',
          iconBgColor: colorFor(a.name),
          size: '',
          iconDataUrl: a.icon,
        })),
      );
    } catch (e: any) {
      setError(String(e?.message || e));
    }
    try {
      const p = await DeviceSearch.checkAll();
      setPerm(p);
      if (p.contacts) {
        const { contacts: list } = await DeviceSearch.getContacts();
        setContacts(
          list.map((c) => ({
            id: `dev_${c.id}`,
            name: c.name,
            phone: c.phone,
            secondaryPhone: c.secondaryPhone,
            email: c.email,
            relationship: 'ফোনবুক',
            avatarColor: colorFor(c.name),
          })),
        );
      }
      if (p.media || p.allFiles) await loadFiles('');
    } catch (e: any) {
      setError(String(e?.message || e));
    }
  }, [loadFiles]);

  useEffect(() => {
    if (isNative) loadAll();
  }, [loadAll]);

  const grant = useCallback(async () => {
    if (!DeviceSearch) return;
    setPerm(await DeviceSearch.requestAll());
    await loadAll();
  }, [loadAll]);

  const grantAllFiles = useCallback(async () => {
    await DeviceSearch?.openAllFilesSettings();
  }, []);

  // Re-check after the user returns from the system settings screen
  useEffect(() => {
    if (!isNative) return;
    const onVis = () => document.visibilityState === 'visible' && loadAll();
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, [loadAll]);

  return { isNative, perm, apps, contacts, files, error, grant, grantAllFiles, searchFiles: loadFiles };
}
