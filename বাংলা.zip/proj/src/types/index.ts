export type SearchCategory =
  | 'all'
  | 'files'
  | 'apps'
  | 'settings'
  | 'contacts'
  | 'youtube'
  | 'web'
  | 'quran'
  | 'ai';

export interface MobileFile {
  id: string;
  name: string;
  category: 'photo' | 'video' | 'audio' | 'document' | 'download' | 'apk';
  size: string;
  updatedAt: string;
  path: string;
  thumbnailUrl?: string;
  mimeType?: string;
  uri?: string;
  tags: string[];
}

export interface InstalledApp {
  id: string;
  name: string;
  nameBn: string;
  packageName: string;
  category: 'social' | 'media' | 'utility' | 'system' | 'finance' | 'communication';
  icon: string;
  iconBgColor: string;
  size: string;
  launchUrl?: string;
  iconDataUrl?: string;
}

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  secondaryPhone?: string;
  email?: string;
  relationship?: string;
  avatarColor: string;
}

export interface QuranSurah {
  number: number;
  nameArabic: string;
  nameEnglish: string;
  nameBengali: string;
  meaning: string;
  versesCount: number;
  revelationType: 'মক্কী' | 'মাদানী';
  popularAyat?: {
    arabic: string;
    bengali: string;
    reference: string;
  };
}

export interface WidgetToolItem {
  id: string;
  label: string;
  labelBn: string;
  iconName: string;
  color: string;
  bgColor: string;
  actionId: string;
  enabled: boolean;
  order: number;
}

export interface WidgetStyleConfig {
  theme: 'glass' | 'dark' | 'emerald' | 'amber' | 'oled' | 'ocean' | 'custom';
  customBgColor: string;
  customTextColor: string;
  borderRadius: 'full' | '2xl' | 'xl' | 'lg';
  opacity: number;
  blurLevel: number;
  glowIntensity: 'none' | 'subtle' | 'vibrant';
  showVoice: boolean;
  showCamera: boolean;
  showMascot: boolean;
}

export interface AiSearchResult {
  summary: string;
  keyFacts?: string[];
  relatedQueries?: string[];
  quranReference?: string | null;
  recommendedSource?: string;
}

export interface VisualSearchResult {
  title: string;
  description: string;
  category?: string;
  tags?: string[];
  textDetected?: string;
  searchKeywords?: string[];
  actionSuggestions?: Array<{ label: string; query?: string; url?: string; action?: string }>;
}
