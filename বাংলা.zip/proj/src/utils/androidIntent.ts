import { DeviceSearch, isNative } from '../plugins/deviceSearch';

export const isAndroid = () => /android/i.test(navigator.userAgent);

/** Android Chrome understands intent:// links; these open real system screens. */
export function openAndroidSetting(action: string): boolean {
  if (isNative && DeviceSearch) { DeviceSearch.openSetting({ action }); return true; }
  if (!isAndroid()) return false;
  window.location.href = `intent:#Intent;action=${action};S.browser_fallback_url=;end`;
  return true;
}

/** Launch an installed app by package name (falls back to Play Store if missing). */
export function openAndroidApp(packageName: string): boolean {
  if (isNative && DeviceSearch) { DeviceSearch.launchApp({ packageName }).catch(() => {}); return true; }
  if (!isAndroid()) return false;
  const fallback = encodeURIComponent(`https://play.google.com/store/apps/details?id=${packageName}`);
  window.location.href = `intent://#Intent;package=${packageName};S.browser_fallback_url=${fallback};end`;
  return true;
}

/** Real phone contacts via Contact Picker API (Android Chrome). Returns null if unsupported. */
export async function pickDeviceContacts(): Promise<
  Array<{ name: string; phone: string; email?: string }> | null
> {
  const nav = navigator as any;
  if (!nav.contacts || !nav.contacts.select) return null;
  const picked = await nav.contacts.select(['name', 'tel', 'email'], { multiple: true });
  return picked
    .filter((c: any) => c.tel && c.tel[0])
    .map((c: any) => ({ name: c.name?.[0] || c.tel[0], phone: c.tel[0], email: c.email?.[0] }));
}
