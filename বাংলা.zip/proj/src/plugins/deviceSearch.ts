/** Bridge to the native Android plugin (native-android/java/DeviceSearchPlugin.java). */
const cap: any = (window as any).Capacitor;

export const isNative: boolean = !!cap?.isNativePlatform?.();

export interface PermissionStatus {
  contacts: boolean;
  media: boolean;
  allFiles: boolean;
}

interface DeviceSearchPlugin {
  checkAll(): Promise<PermissionStatus>;
  requestAll(): Promise<PermissionStatus>;
  openAllFilesSettings(): Promise<void>;
  getApps(): Promise<{ apps: Array<{ name: string; packageName: string; system: boolean; icon?: string }> }>;
  launchApp(o: { packageName: string }): Promise<void>;
  getContacts(): Promise<{
    contacts: Array<{ id: string; name: string; phone: string; secondaryPhone?: string; email?: string }>;
  }>;
  searchFiles(o: { query?: string; category?: string; limit?: number }): Promise<{
    files: Array<{
      id: number; name: string; size: number; updatedAt: number; mime: string;
      category: 'photo' | 'video' | 'audio' | 'document' | 'apk'; path?: string; uri: string;
    }>;
  }>;
  openFile(o: { path?: string; uri?: string; mime?: string }): Promise<void>;
  openSetting(o: { action: string }): Promise<void>;
}

export const DeviceSearch: DeviceSearchPlugin | null = isNative
  ? (cap.registerPlugin ? cap.registerPlugin('DeviceSearch') : cap.Plugins?.DeviceSearch)
  : null;
