export interface AndroidSettingItem {
  id: string;
  name: string;
  nameBn: string;
  action: string;
  keywords: string[];
  emoji: string;
}

const S = (id: string, name: string, nameBn: string, action: string, emoji: string, keywords: string[] = []): AndroidSettingItem => ({
  id, name, nameBn, action, emoji, keywords,
});

export const ANDROID_SETTINGS: AndroidSettingItem[] = [
  S('main', 'Settings', 'সেটিংস', 'android.settings.SETTINGS', '⚙️', ['settings', 'সেটিং']),
  S('wifi', 'Wi-Fi', 'ওয়াইফাই', 'android.settings.WIFI_SETTINGS', '📶', ['wifi', 'internet', 'ইন্টারনেট', 'নেটওয়ার্ক']),
  S('bluetooth', 'Bluetooth', 'ব্লুটুথ', 'android.settings.BLUETOOTH_SETTINGS', '🔵', ['bluetooth', 'ব্লুটুথ', 'pair']),
  S('mobiledata', 'Mobile network & data', 'মোবাইল ডাটা', 'android.settings.DATA_ROAMING_SETTINGS', '📡', ['data', 'sim', 'ডাটা', 'সিম', 'roaming']),
  S('airplane', 'Airplane mode', 'ফ্লাইট মোড', 'android.settings.AIRPLANE_MODE_SETTINGS', '✈️', ['airplane', 'flight', 'ফ্লাইট']),
  S('hotspot', 'Hotspot & tethering', 'হটস্পট', 'android.settings.TETHER_SETTINGS', '🔥', ['hotspot', 'tethering', 'হটস্পট']),
  S('datausage', 'Data usage', 'ডাটা ব্যবহার', 'android.settings.DATA_USAGE_SETTINGS', '📊', ['data usage', 'ডাটা ব্যবহার']),
  S('nfc', 'NFC', 'এনএফসি', 'android.settings.NFC_SETTINGS', '📲', ['nfc', 'tap']),
  S('display', 'Display', 'ডিসপ্লে', 'android.settings.DISPLAY_SETTINGS', '🖥️', ['display', 'brightness', 'ব্রাইটনেস', 'screen timeout', 'dark mode', 'ডার্ক মোড', 'font', 'ফন্ট']),
  S('sound', 'Sound & volume', 'সাউন্ড ও ভলিউম', 'android.settings.SOUND_SETTINGS', '🔊', ['sound', 'volume', 'ringtone', 'রিংটোন', 'ভলিউম', 'silent']),
  S('dnd', 'Do Not Disturb', 'বিরক্ত করবেন না', 'android.settings.ZEN_MODE_SETTINGS', '🔕', ['dnd', 'silent', 'disturb']),
  S('notifications', 'Notifications', 'নোটিফিকেশন', 'android.settings.ALL_APPS_NOTIFICATION_SETTINGS', '🔔', ['notification', 'নোটিফিকেশন']),
  S('battery', 'Battery', 'ব্যাটারি', 'android.intent.action.POWER_USAGE_SUMMARY', '🔋', ['battery', 'ব্যাটারি', 'charge', 'power']),
  S('batterysaver', 'Battery saver', 'ব্যাটারি সেভার', 'android.settings.BATTERY_SAVER_SETTINGS', '🪫', ['battery saver', 'power saving']),
  S('storage', 'Storage', 'স্টোরেজ', 'android.settings.INTERNAL_STORAGE_SETTINGS', '💾', ['storage', 'space', 'স্টোরেজ', 'জায়গা', 'memory']),
  S('apps', 'Apps', 'অ্যাপস', 'android.settings.APPLICATION_SETTINGS', '📱', ['apps', 'application', 'অ্যাপ', 'uninstall']),
  S('defaultapps', 'Default apps', 'ডিফল্ট অ্যাপ', 'android.settings.MANAGE_DEFAULT_APPS_SETTINGS', '✅', ['default', 'ডিফল্ট', 'browser']),
  S('location', 'Location', 'লোকেশন', 'android.settings.LOCATION_SOURCE_SETTINGS', '📍', ['location', 'gps', 'লোকেশন']),
  S('security', 'Security', 'নিরাপত্তা', 'android.settings.SECURITY_SETTINGS', '🔒', ['security', 'lock', 'password', 'fingerprint', 'পাসওয়ার্ড', 'ফিঙ্গারপ্রিন্ট', 'নিরাপত্তা']),
  S('privacy', 'Privacy', 'গোপনীয়তা', 'android.settings.PRIVACY_SETTINGS', '🛡️', ['privacy', 'permission', 'গোপনীয়তা', 'পারমিশন']),
  S('accounts', 'Accounts', 'অ্যাকাউন্ট', 'android.settings.SYNC_SETTINGS', '👤', ['account', 'sync', 'google', 'অ্যাকাউন্ট']),
  S('addaccount', 'Add account', 'অ্যাকাউন্ট যোগ', 'android.settings.ADD_ACCOUNT_SETTINGS', '➕', ['add account']),
  S('language', 'Language & input', 'ভাষা ও ইনপুট', 'android.settings.LOCALE_SETTINGS', '🌐', ['language', 'locale', 'ভাষা', 'বাংলা']),
  S('keyboard', 'Keyboard', 'কীবোর্ড', 'android.settings.INPUT_METHOD_SETTINGS', '⌨️', ['keyboard', 'input', 'কীবোর্ড', 'typing']),
  S('datetime', 'Date & time', 'তারিখ ও সময়', 'android.settings.DATE_SETTINGS', '🕒', ['date', 'time', 'timezone', 'তারিখ', 'সময়']),
  S('accessibility', 'Accessibility', 'অ্যাক্সেসিবিলিটি', 'android.settings.ACCESSIBILITY_SETTINGS', '♿', ['accessibility', 'talkback', 'magnifier']),
  S('wallpaper', 'Wallpaper', 'ওয়ালপেপার', 'android.intent.action.SET_WALLPAPER', '🖼️', ['wallpaper', 'ওয়ালপেপার', 'theme']),
  S('cast', 'Cast', 'কাস্ট', 'android.settings.CAST_SETTINGS', '📺', ['cast', 'screen mirror']),
  S('printing', 'Printing', 'প্রিন্টিং', 'android.settings.ACTION_PRINT_SETTINGS', '🖨️', ['print']),
  S('vpn', 'VPN', 'ভিপিএন', 'android.settings.VPN_SETTINGS', '🔐', ['vpn']),
  S('devinfo', 'About phone', 'ফোন সম্পর্কে', 'android.settings.DEVICE_INFO_SETTINGS', 'ℹ️', ['about', 'device info', 'version', 'imei', 'model', 'ফোন সম্পর্কে']),
  S('developer', 'Developer options', 'ডেভেলপার অপশন', 'android.settings.APPLICATION_DEVELOPMENT_SETTINGS', '🧑‍💻', ['developer', 'usb debugging']),
  S('update', 'System update', 'সিস্টেম আপডেট', 'android.settings.SYSTEM_UPDATE_SETTINGS', '⬆️', ['update', 'software', 'আপডেট']),
  S('backup', 'Backup & reset', 'ব্যাকআপ ও রিসেট', 'android.settings.PRIVACY_SETTINGS', '♻️', ['backup', 'reset', 'factory']),
  S('usersettings', 'Users', 'ইউজার', 'android.settings.USER_SETTINGS', '👥', ['users', 'guest']),
  S('wifiip', 'Wi-Fi IP', 'ওয়াইফাই আইপি', 'android.settings.WIFI_IP_SETTINGS', '🧭', ['ip']),
  S('capture', 'Cast & screen record', 'স্ক্রিন কাস্ট', 'android.settings.CAST_SETTINGS', '🎥', ['record']),
  S('overlay', 'Display over other apps', 'অন্য অ্যাপের ওপর দেখান', 'android.settings.action.MANAGE_OVERLAY_PERMISSION', '🪟', ['overlay', 'draw over', 'floating']),
  S('writesettings', 'Modify system settings', 'সিস্টেম সেটিং পরিবর্তন', 'android.settings.action.MANAGE_WRITE_SETTINGS', '✍️', ['write settings']),
  S('allfiles', 'All files access', 'সব ফাইলে অ্যাক্সেস', 'android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION', '📂', ['all files', 'manage storage']),
  S('usage', 'Usage access', 'ব্যবহারের অ্যাক্সেস', 'android.settings.USAGE_ACCESS_SETTINGS', '📈', ['usage']),
  S('notiflistener', 'Notification access', 'নোটিফিকেশন অ্যাক্সেস', 'android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS', '🛎️', ['listener']),
  S('batteryopt', 'Battery optimization', 'ব্যাটারি অপটিমাইজেশন', 'android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS', '⚡', ['optimization', 'background']),
  S('alarms', 'Alarms & reminders', 'অ্যালার্ম', 'android.settings.REQUEST_SCHEDULE_EXACT_ALARM', '⏰', ['alarm']),
  S('digitalwellbeing', 'Digital wellbeing', 'ডিজিটাল ওয়েলবিয়িং', 'android.settings.SETTINGS', '🧘', ['screen time', 'wellbeing']),
];

export function searchSettings(query: string): AndroidSettingItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return ANDROID_SETTINGS;
  return ANDROID_SETTINGS.filter(
    (s) =>
      s.name.toLowerCase().includes(q) ||
      s.nameBn.toLowerCase().includes(q) ||
      s.keywords.some((k) => k.toLowerCase().includes(q)),
  );
}
