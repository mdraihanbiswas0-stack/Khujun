import React, { useState } from 'react';
import { searchSettings } from '../data/androidSettings';
import { openAndroidSetting, isAndroid } from '../utils/androidIntent';

export const SettingsSearchSection: React.FC<{ query: string }> = ({ query }) => {
  const [msg, setMsg] = useState('');
  const items = searchSettings(query);
  if (items.length === 0) return null;

  const open = (action: string) => {
    if (!openAndroidSetting(action)) {
      setMsg('সেটিংস সরাসরি খুলতে অ্যান্ড্রয়েড ফোনে Chrome বা ইনস্টল করা অ্যাপ থেকে চালান।');
    }
  };

  return (
    <section className="space-y-3">
      <h3 className="text-sm font-bold text-cyan-300">⚙️ ফোন সেটিংস ({items.length})</h3>
      {msg && !isAndroid() && <p className="text-xs text-amber-300">{msg}</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {items.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => open(s.action)}
            className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-400/60 text-left"
          >
            <span className="text-xl">{s.emoji}</span>
            <span>
              <span className="block text-sm text-slate-100">{s.nameBn}</span>
              <span className="block text-[11px] text-slate-400">{s.name}</span>
            </span>
          </button>
        ))}
      </div>
    </section>
  );
};
