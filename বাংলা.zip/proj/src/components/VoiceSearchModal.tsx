import React, { useState, useEffect } from 'react';
import { Mic, MicOff, X, Sparkles, Volume2, Globe } from 'lucide-react';

interface VoiceSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyQuery: (q: string) => void;
}

export const VoiceSearchModal: React.FC<VoiceSearchModalProps> = ({
  isOpen,
  onClose,
  onApplyQuery,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lang, setLang] = useState<'bn-BD' | 'en-US'>('bn-BD');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setIsListening(false);
      setTranscript('');
      setErrorMsg(null);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorMsg('আপনার ব্রাউজারে স্পিচ রিকগনিশন সাপোর্ট নেই। অনুগ্রহ করে ক্রোম ব্রাউজার ব্যবহার করুন।');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = lang;
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      setIsListening(true);
      setErrorMsg(null);
    };

    recognition.onresult = (event: any) => {
      let current = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        current += event.results[i][0].transcript;
      }
      setTranscript(current);
      if (event.results[0].isFinal) {
        setTimeout(() => {
          onApplyQuery(current);
          onClose();
        }, 800);
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
      if (event.error === 'not-allowed') {
        setErrorMsg('মাইক্রোফোন পারমিশন প্রয়োজন। অনুগ্রহ করে পারমিশন এলাও করুন।');
      } else {
        setErrorMsg('শব্দ পরিষ্কারভাবে বোঝা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।');
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    try {
      recognition.start();
    } catch {
      // Speech recognition might already be running
    }

    return () => {
      try {
        recognition.stop();
      } catch {}
    };
  }, [isOpen, lang]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl text-center space-y-5">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 text-cyan-300 text-xs font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>জোনাকি ভয়েস সার্চ</span>
          </div>
          <h3 className="text-lg font-bold text-slate-100">
            {isListening ? 'কথা বলুন, জোনাকি শুনছে...' : 'মাইক্রোফোনে চাপ দিয়ে বলুন'}
          </h3>
          <p className="text-xs text-slate-400">
            যেকোনো ফাইল, গান, অ্যাপস, কন্টাক্ট বা অনলাইনের বিষয় মুখে বলুন
          </p>
        </div>

        {/* Animated Pulse Mic */}
        <div className="relative py-4 flex items-center justify-center">
          {isListening && (
            <>
              <div className="absolute w-32 h-32 rounded-full bg-cyan-500/20 animate-ping pointer-events-none" />
              <div className="absolute w-24 h-24 rounded-full bg-cyan-400/30 animate-pulse pointer-events-none" />
            </>
          )}

          <div
            className={`w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 ${
              isListening
                ? 'bg-gradient-to-tr from-cyan-500 to-blue-500 text-white shadow-cyan-500/50 scale-110'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            <Mic className="w-9 h-9" />
          </div>
        </div>

        {/* Transcript or Instructions */}
        <div className="min-h-[60px] p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-center">
          {transcript ? (
            <p className="text-sm font-semibold text-cyan-300 animate-in fade-in">
              "{transcript}"
            </p>
          ) : errorMsg ? (
            <p className="text-xs text-amber-400">{errorMsg}</p>
          ) : (
            <p className="text-xs text-slate-500 italic">
              উদাহরণ: "আম্মুর ফোন নম্বর", "রবীন্দ্রসংগীত অডিও", "ইউটিউব গান"
            </p>
          )}
        </div>

        {/* Language selector & Manual search action */}
        <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800">
          <div className="flex items-center gap-1">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <button
              type="button"
              onClick={() => setLang(lang === 'bn-BD' ? 'en-US' : 'bn-BD')}
              className="text-cyan-400 font-semibold hover:underline"
            >
              ভাষা: {lang === 'bn-BD' ? 'বাংলা (BD)' : 'English (US)'}
            </button>
          </div>

          {transcript && (
            <button
              type="button"
              onClick={() => {
                onApplyQuery(transcript);
                onClose();
              }}
              className="px-4 py-1.5 rounded-full bg-cyan-400 text-slate-950 font-bold text-xs hover:bg-cyan-300 transition-colors"
            >
              সার্চ করুন
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
