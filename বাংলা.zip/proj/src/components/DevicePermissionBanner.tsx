import React from 'react';
import { PermissionStatus } from '../plugins/deviceSearch';

interface Props {
  perm: PermissionStatus | null;
  error: string;
  onGrant: () => void;
  onGrantAllFiles: () => void;
}

export const DevicePermissionBanner: React.FC<Props> = ({ perm, error, onGrant, onGrantAllFiles }) => {
  const missingBasic = !perm || !perm.contacts || !perm.media;
  const missingAll = perm && !perm.allFiles;
  if (!missingBasic && !missingAll && !error) return null;
  return (
    <div className="rounded-2xl p-4 bg-slate-900/80 border border-amber-500/40 space-y-3 text-sm">
      {missingBasic && (
        <div className="flex items-center justify-between gap-3">
          <p className="text-slate-200">কন্টাক্ট, ছবি, ভিডিও ও গান খুঁজতে অনুমতি দিন।</p>
          <button onClick={onGrant} className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs shrink-0">
            অনুমতি দিন
          </button>
        </div>
      )}
      {missingAll && (
        <div className="flex items-center justify-between gap-3">
          <p className="text-slate-200">PDF, ডকুমেন্ট ও ডাউনলোড ফোল্ডারের ফাইল খুঁজতে "সব ফাইলে অ্যাক্সেস" চালু করুন।</p>
          <button onClick={onGrantAllFiles} className="px-3 py-1.5 rounded-xl bg-cyan-400 text-slate-950 font-bold text-xs shrink-0">
            চালু করুন
          </button>
        </div>
      )}
      {error && <p className="text-xs text-red-300">ত্রুটি: {error}</p>}
    </div>
  );
};
