import React, { useState } from 'react';
import { Search, X, Mic, Camera, Sparkles } from 'lucide-react';
import { JonakiFirefly } from './JonakiFirefly';

interface FloatingMiniWidgetProps {
  isVisible: boolean;
  onClose: () => void;
  onSearch: (q: string) => void;
  onOpenCamera: () => void;
  onOpenVoice: () => void;
}

export const FloatingMiniWidget: React.FC<FloatingMiniWidgetProps> = ({
  isVisible,
  onClose,
  onSearch,
  onOpenCamera,
  onOpenVoice,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputVal, setInputVal] = useState('');

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 animate-in fade-in slide-in-from-bottom-4">
      {!isExpanded ? (
        /* Minimized Floating Jonaki Bubble */
        <div
          role="button"
          tabIndex={0}
          onClick={() => setIsExpanded(true)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setIsExpanded(true);
            }
          }}
          className="relative p-2.5 rounded-full bg-slate-900/95 border border-amber-400/40 shadow-2xl flex items-center gap-2 group backdrop-blur-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="ভাসমান জোনাকি উইজেট খুলুন"
        >
          <div className="absolute -inset-1 rounded-full bg-amber-400/20 blur-md pointer-events-none" />
          <JonakiFirefly size="sm" showSpeechBubble={false} interactive={false} />
          <span className="text-xs font-bold text-amber-300 pr-1 hidden sm:inline">
            জোনাকি সার্চ
          </span>
          <Search className="w-3.5 h-3.5 text-amber-400" />
        </div>
      ) : (
        /* Expanded Floating Search Bar */
        <div className="relative w-[300px] sm:w-[360px] p-2 rounded-full bg-slate-900/95 border border-amber-400/50 shadow-2xl backdrop-blur-lg flex items-center gap-2 animate-in zoom-in-95">
          <JonakiFirefly size="sm" showSpeechBubble={false} interactive={false} />

          <input
            type="text"
            autoFocus
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onSearch(inputVal);
                setIsExpanded(false);
              }
            }}
            placeholder="যেকোনো কিছু লিখুন..."
            className="flex-1 bg-transparent text-xs text-slate-100 placeholder-slate-400 outline-none truncate"
          />

          <button
            type="button"
            onClick={onOpenCamera}
            className="p-1.5 rounded-full bg-pink-500/20 text-pink-400 hover:bg-pink-500/30 transition-colors shrink-0"
            title="ক্যামেরা"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onOpenVoice}
            className="p-1.5 rounded-full bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-colors shrink-0"
            title="ভয়েস"
          >
            <Mic className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(false)}
            className="p-1 rounded-full text-slate-400 hover:text-white transition-colors shrink-0"
            title="সংকোচন করুন"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
