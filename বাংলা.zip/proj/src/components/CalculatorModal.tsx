import React, { useState } from 'react';
import { X, Calculator, Delete } from 'lucide-react';

interface CalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CalculatorModal: React.FC<CalculatorModalProps> = ({ isOpen, onClose }) => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (display === '0') {
      setDisplay(digit);
    } else {
      setDisplay(display + digit);
    }
  };

  const handleOperator = (op: string) => {
    setEquation(`${display} ${op} `);
    setDisplay('0');
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const handleEquals = () => {
    try {
      const fullExpr = equation + display;
      // safe simple evaluation of basic math operations
      const sanitized = fullExpr.replace(/×/g, '*').replace(/÷/g, '/');
      // eslint-disable-next-line no-eval
      const result = Function(`'use strict'; return (${sanitized})`)();
      setDisplay(String(result));
      setEquation('');
    } catch {
      setDisplay('Error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xs bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Calculator className="w-4 h-4" />
            </span>
            <h3 className="text-sm font-bold text-slate-100">কুইক ক্যালকুলেটর</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Display Screen */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-right space-y-1">
          <div className="text-[11px] font-mono text-slate-500 h-4">{equation}</div>
          <div className="text-2xl font-bold font-mono text-amber-300 truncate tracking-wider">
            {display}
          </div>
        </div>

        {/* Keypad Grid */}
        <div className="grid grid-cols-4 gap-2">
          <button
            type="button"
            onClick={handleClear}
            className="p-3 rounded-xl bg-red-500/20 text-red-400 font-bold text-xs"
          >
            AC
          </button>
          <button
            type="button"
            onClick={() => handleOperator('÷')}
            className="p-3 rounded-xl bg-slate-800 text-cyan-400 font-bold text-sm"
          >
            ÷
          </button>
          <button
            type="button"
            onClick={() => handleOperator('×')}
            className="p-3 rounded-xl bg-slate-800 text-cyan-400 font-bold text-sm"
          >
            ×
          </button>
          <button
            type="button"
            onClick={() => setDisplay(display.length > 1 ? display.slice(0, -1) : '0')}
            className="p-3 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center"
          >
            <Delete className="w-4 h-4" />
          </button>

          {['7', '8', '9'].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handleDigit(d)}
              className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-sm hover:bg-slate-800"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={() => handleOperator('-')}
            className="p-3 rounded-xl bg-slate-800 text-cyan-400 font-bold text-sm"
          >
            -
          </button>

          {['4', '5', '6'].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handleDigit(d)}
              className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-sm hover:bg-slate-800"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={() => handleOperator('+')}
            className="p-3 rounded-xl bg-slate-800 text-cyan-400 font-bold text-sm"
          >
            +
          </button>

          {['1', '2', '3'].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handleDigit(d)}
              className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-sm hover:bg-slate-800"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={handleEquals}
            className="row-span-2 p-3 rounded-xl bg-amber-400 text-slate-950 font-bold text-base hover:bg-amber-300 flex items-center justify-center shadow-md"
          >
            =
          </button>

          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="col-span-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-sm hover:bg-slate-800"
          >
            0
          </button>
          <button
            type="button"
            onClick={() => !display.includes('.') && setDisplay(display + '.')}
            className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 font-bold text-sm"
          >
            .
          </button>
        </div>
      </div>
    </div>
  );
};
