import React, { useState } from 'react';
import {
  Camera,
  Mic,
  Folder,
  Users,
  ClipboardCopy,
  CheckCircle2,
  Lock,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface PermissionsQuickAccessProps {
  onQuickAction: (actionId: string) => void;
}

export const PermissionsQuickAccess: React.FC<PermissionsQuickAccessProps> = ({
  onQuickAction,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [permissions, setPermissions] = useState({
    camera: false,
    microphone: false,
    storage: true,
    contacts: true,
    clipboard: false,
  });

  const requestCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach((t) => t.stop());
      setPermissions((prev) => ({ ...prev, camera: true }));
    } catch {
      setPermissions((prev) => ({ ...prev, camera: false }));
    }
  };

  const requestMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setPermissions((prev) => ({ ...prev, microphone: true }));
    } catch {
      setPermissions((prev) => ({ ...prev, microphone: false }));
    }
  };

  const requestClipboard = async () => {
    try {
      await navigator.clipboard.readText();
      setPermissions((prev) => ({ ...prev, clipboard: true }));
    } catch {
      setPermissions((prev) => ({ ...prev, clipboard: true }));
    }
  };

  const items = [
    {
      id: 'camera',
      label: 'ক্যামেরা ও QR',
      desc: 'ছবি ও বারকোড স্ক্যান',
      icon: Camera,
      active: permissions.camera,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/15',
      action: requestCamera,
    },
    {
      id: 'voice',
      label: 'ভয়েস মাইক্রোফোন',
      desc: 'মুখে বলে সার্চ',
      icon: Mic,
      active: permissions.microphone,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/15',
      action: requestMic,
    },
    {
      id: 'files',
      label: 'স্টোরেজ ও ফাইল',
      desc: 'ফটো, ভিডিও, অডিও ও ডকুমেন্টস',
      icon: Folder,
      active: permissions.storage,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/15',
      action: () => onQuickAction('files'),
    },
    {
      id: 'contacts',
      label: 'ফোনবুক কন্টাক্ট',
      desc: 'সরাসরি কল ও এসএমএস',
      icon: Users,
      active: permissions.contacts,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/15',
      action: () => onQuickAction('contacts'),
    },
    {
      id: 'clipboard',
      label: 'ক্লিপবোর্ড অ্যাক্সেস',
      desc: 'কপি করা টেক্সট দিয়ে সার্চ',
      icon: ClipboardCopy,
      active: permissions.clipboard,
      color: 'text-lime-400',
      bgColor: 'bg-lime-500/15',
      action: requestClipboard,
    },
  ];

  return (
    <div className="w-full rounded-2xl bg-slate-900/80 border border-slate-800 p-3 sm:p-4 shadow-sm transition-all">
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between cursor-pointer select-none"
      >
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-amber-400/20 text-amber-300">
            <Sparkles className="w-4 h-4" />
          </span>
          <h3 className="text-xs sm:text-sm font-bold text-slate-200">
            কুইক এক্সেস ও পারমিশন হাব (Quick Permissions)
          </h3>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="hidden sm:inline text-[11px]">এক ক্লিকে পারমিশন ও টুলস চালু করুন</span>
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-3 mt-3 border-t border-slate-800/80">
          {items.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={item.action}
                className="p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-850 border border-slate-800/80 text-left transition-all group flex flex-col justify-between"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className={`p-2 rounded-lg ${item.bgColor} ${item.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  {item.active ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Lock className="w-3 h-3 text-slate-500" />
                  )}
                </div>
                <div>
                  <h4 className="text-[11px] font-semibold text-slate-200 group-hover:text-amber-300 transition-colors truncate">
                    {item.label}
                  </h4>
                  <p className="text-[9px] text-slate-400 truncate">{item.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
