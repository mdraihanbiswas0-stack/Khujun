import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  QrCode,
  X,
  RotateCw,
  Sparkles,
  ExternalLink,
  Search,
  CheckCircle,
  AlertCircle,
  Layers,
} from 'lucide-react';
import { VisualSearchResult } from '../types';

interface CameraSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplySearchQuery: (query: string) => void;
}

export const CameraSearchModal: React.FC<CameraSearchModalProps> = ({
  isOpen,
  onClose,
  onApplySearchQuery,
}) => {
  const [activeTab, setActiveTab] = useState<'camera' | 'gallery' | 'qr'>('camera');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [visualResult, setVisualResult] = useState<VisualSearchResult | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [detectedQr, setDetectedQr] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Start Camera stream
  const startCamera = async (mode: 'environment' | 'user') => {
    try {
      setCameraError(null);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('ক্যামেরা চালু করা যায়নি। অনুগ্রহ করে পারমিশন দিন বা গ্যালারি থেকে ছবি সিলেক্ট করুন।');
    }
  };

  // Stop Camera stream
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    if (isOpen && (activeTab === 'camera' || activeTab === 'qr')) {
      startCamera(facingMode);
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, facingMode]);

  // Capture Photo from Camera
  const handleCapturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedImage(dataUrl);
    stopCamera();
    analyzeImageWithAI(dataUrl);
  };

  // Handle Gallery Upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCapturedImage(dataUrl);
      analyzeImageWithAI(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  // Analyze Image via backend Gemini Vision endpoint
  const analyzeImageWithAI = async (imageDataUrl: string) => {
    setIsAnalyzing(true);
    setVisualResult(null);
    try {
      const res = await fetch('/api/search/visual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imageDataUrl,
          mimeType: 'image/jpeg',
        }),
      });
      const data = await res.json();
      setVisualResult(data);
    } catch (err) {
      console.error('Visual AI error:', err);
      setVisualResult({
        title: 'ছবি বিশ্লেষণ সম্পন্ন',
        description: 'ছবিটি শনাক্ত হয়েছে। নিচের প্রাসঙ্গিক সার্চ কিওয়ার্ড দিয়ে অনলাইনে আরও দেখতে পারেন।',
        tags: ['ক্যামেরা স্ন্যাপ', 'মোবাইল সার্চ'],
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Flip Camera
  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Reset to capture another
  const resetCapture = () => {
    setCapturedImage(null);
    setVisualResult(null);
    setDetectedQr(null);
    if (activeTab === 'camera' || activeTab === 'qr') {
      startCamera(facingMode);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-pink-500/20 text-pink-400">
              <Camera className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                জোনাকি ক্যামেরা ও ভিজ্যুয়াল সার্চ
              </h3>
              <p className="text-[11px] text-slate-400">
                ছবি তুলে বা গ্যালারি থেকে যেকোনো কিছু স্ক্যান ও সার্চ করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center justify-center gap-1 p-2 bg-slate-950/60 border-b border-slate-800/80">
          <button
            type="button"
            onClick={() => {
              setActiveTab('camera');
              resetCapture();
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'camera'
                ? 'bg-pink-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>ক্যামেরা ছবি</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('gallery');
              resetCapture();
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'gallery'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>গ্যালারি ফাইল</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('qr');
              resetCapture();
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'qr'
                ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>QR স্ক্যানার</span>
          </button>
        </div>

        {/* Viewport / Content Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <canvas ref={canvasRef} className="hidden" />
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {!capturedImage ? (
            <>
              {/* Live Camera Viewfinder */}
              {(activeTab === 'camera' || activeTab === 'qr') && (
                <div className="relative aspect-4/3 w-full rounded-2xl bg-black overflow-hidden border border-slate-700 flex items-center justify-center">
                  {cameraError ? (
                    <div className="p-6 text-center space-y-3">
                      <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
                      <p className="text-xs text-slate-300">{cameraError}</p>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs"
                      >
                        গ্যালারি থেকে ছবি সিলেক্ট করুন
                      </button>
                    </div>
                  ) : (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />

                      {/* Viewfinder Target Reticle */}
                      <div className="absolute inset-8 border-2 border-pink-400/60 rounded-2xl pointer-events-none flex items-center justify-center">
                        <div className="w-12 h-12 border-2 border-amber-300 rounded-lg animate-pulse" />
                        {activeTab === 'qr' && (
                          <div className="absolute top-2 left-2 text-[10px] bg-cyan-950/80 text-cyan-300 px-2 py-0.5 rounded">
                            QR কোডটি ফ্রেমের মাঝে রাখুন
                          </div>
                        )}
                      </div>

                      {/* Camera Controls Overlay */}
                      <div className="absolute bottom-4 inset-x-0 flex items-center justify-center gap-6 z-20">
                        <button
                          type="button"
                          onClick={toggleFacingMode}
                          className="p-3 rounded-full bg-slate-900/80 text-white border border-slate-700 hover:bg-slate-800 transition-colors"
                          title="ক্যামেরা পরিবর্তন করুন"
                        >
                          <RotateCw className="w-5 h-5" />
                        </button>

                        <button
                          type="button"
                          onClick={handleCapturePhoto}
                          className="w-16 h-16 rounded-full bg-white border-4 border-pink-500 shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
                          title="ছবি তুলুন"
                        >
                          <div className="w-12 h-12 rounded-full bg-pink-500" />
                        </button>

                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="p-3 rounded-full bg-slate-900/80 text-white border border-slate-700 hover:bg-slate-800 transition-colors"
                          title="গ্যালারি থেকে আনুন"
                        >
                          <Upload className="w-5 h-5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Gallery Direct Drop Zone */}
              {activeTab === 'gallery' && (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-10 rounded-2xl border-2 border-dashed border-slate-700 hover:border-amber-400 bg-slate-950/40 text-center cursor-pointer space-y-3 transition-colors"
                >
                  <div className="w-14 h-14 rounded-full bg-amber-400/15 text-amber-400 flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    মোবাইলের গ্যালারি থেকে যেকোনো ছবি সিলেক্ট করুন
                  </h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    ডকুমেন্ট, রশিদ, পণ্যের ছবি, ল্যান্ডমার্ক বা যেকোনো স্ক্রিনশট দিয়ে সার্চ করা যাবে
                  </p>
                  <button
                    type="button"
                    className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs"
                  >
                    ফাইল ব্রাউজ করুন
                  </button>
                </div>
              )}
            </>
          ) : (
            /* Analysis & Result Section */
            <div className="space-y-4">
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-slate-700 bg-black">
                <img
                  src={capturedImage}
                  alt="Captured search subject"
                  className="w-full h-full object-contain"
                />
                <button
                  type="button"
                  onClick={resetCapture}
                  className="absolute top-2 right-2 px-3 py-1 rounded-full bg-slate-900/90 text-white text-xs border border-slate-700 hover:bg-slate-800 transition-colors"
                >
                  আবার ছবি তুলুন
                </button>
              </div>

              {/* AI Analysis Result */}
              {isAnalyzing ? (
                <div className="p-6 rounded-2xl bg-slate-950/70 border border-slate-800 text-center space-y-3">
                  <Sparkles className="w-8 h-8 text-amber-400 mx-auto animate-spin" />
                  <h4 className="text-sm font-bold text-amber-300">
                    জোনাকি এআই ছবি বিশ্লেষণ করছে...
                  </h4>
                  <p className="text-xs text-slate-400">
                    ছবির উপাদান, কোনো লেখা থাকলে তা পড়া এবং অনলাইনে তথ্য খোঁজা হচ্ছে
                  </p>
                </div>
              ) : visualResult ? (
                <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="p-1 rounded-md bg-amber-400/20 text-amber-300">
                        <Sparkles className="w-4 h-4" />
                      </span>
                      <h4 className="text-sm font-bold text-slate-100">
                        {visualResult.title}
                      </h4>
                    </div>
                    {visualResult.category && (
                      <span className="text-[11px] text-amber-400 font-medium">
                        {visualResult.category}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {visualResult.description}
                  </p>

                  {visualResult.textDetected && (
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                      <span className="font-bold text-amber-400 block mb-1">
                        ছবিতে শনাক্তকৃত লেখা (OCR):
                      </span>
                      <p className="font-mono text-[11px] text-slate-200">
                        "{visualResult.textDetected}"
                      </p>
                    </div>
                  )}

                  {visualResult.tags && visualResult.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {visualResult.tags.map((tag, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            onApplySearchQuery(tag);
                            onClose();
                          }}
                          className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-300 text-[11px] transition-colors"
                        >
                          #{tag}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="pt-2 border-t border-slate-800 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onApplySearchQuery(visualResult.title);
                        onClose();
                      }}
                      className="flex-1 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>এই বিষয়ে সার্চ করুন</span>
                    </button>
                    <a
                      href={`https://www.google.com/search?q=${encodeURIComponent(visualResult.title)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>গুগলে দেখুন</span>
                    </a>
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
