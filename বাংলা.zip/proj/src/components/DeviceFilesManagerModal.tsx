import React, { useState, useRef } from 'react';
import {
  Folder,
  FileText,
  Image as ImageIcon,
  Film,
  Music,
  Download,
  Plus,
  X,
  Search,
  HardDrive,
  Eye,
  Trash2,
} from 'lucide-react';
import { MobileFile } from '../types';

interface DeviceFilesManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: MobileFile[];
  onAddFiles: (newFiles: MobileFile[]) => void;
  onPreviewFile: (file: MobileFile) => void;
}

export const DeviceFilesManagerModal: React.FC<DeviceFilesManagerModalProps> = ({
  isOpen,
  onClose,
  files,
  onAddFiles,
  onPreviewFile,
}) => {
  const [filterCat, setFilterCat] = useState<string>('all');
  const [localQuery, setLocalQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle uploading real files from computer or mobile storage
  const handleRealFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!uploaded || uploaded.length === 0) return;

    const newMobileFiles: MobileFile[] = Array.from(uploaded).map((f, i) => {
      let cat: MobileFile['category'] = 'document';
      if (f.type.startsWith('image/')) cat = 'photo';
      else if (f.type.startsWith('video/')) cat = 'video';
      else if (f.type.startsWith('audio/')) cat = 'audio';
      else if (f.name.endsWith('.apk')) cat = 'apk';

      const sizeKb = (f.size / 1024).toFixed(1);
      const sizeMb = (f.size / (1024 * 1024)).toFixed(1);
      const sizeStr = f.size > 1024 * 1024 ? `${sizeMb} MB` : `${sizeKb} KB`;

      return {
        id: `user-file-${Date.now()}-${i}`,
        name: f.name,
        category: cat,
        size: sizeStr,
        updatedAt: new Date().toISOString().split('T')[0],
        path: `/Internal Storage/UserFiles/${f.name}`,
        tags: [f.name.toLowerCase(), cat, 'ডিভাইস ফাইল', 'ইউজার আপলোড'],
      };
    });

    onAddFiles(newMobileFiles);
  };

  const filteredFiles = files.filter((f) => {
    const matchesCat = filterCat === 'all' || f.category === filterCat;
    const matchesQuery =
      !localQuery ||
      f.name.toLowerCase().includes(localQuery.toLowerCase()) ||
      f.path.toLowerCase().includes(localQuery.toLowerCase()) ||
      f.tags.some((t) => t.toLowerCase().includes(localQuery.toLowerCase()));
    return matchesCat && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
              <Folder className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                মোবাইল স্টোরেজ ও ফাইল ম্যানেজার
              </h3>
              <p className="text-[11px] text-slate-400">
                ইন্টারনাল মেমোরি ও এসডি কার্ডের সব ফাইল খুঁজুন ও ম্যানেজ করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Storage Bar Indicator */}
        <div className="px-5 py-3 bg-slate-950/60 border-b border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-amber-400" />
              <span>ইন্টারনাল মেমোরি (Internal Storage)</span>
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              ৬৪.২ GB ব্যবহৃত / ১২৮ GB
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
            <div className="h-full bg-pink-500 w-[25%]" title="ছবি" />
            <div className="h-full bg-indigo-500 w-[20%]" title="ভিডিও" />
            <div className="h-full bg-purple-500 w-[10%]" title="গান" />
            <div className="h-full bg-amber-400 w-[15%]" title="ডকুমেন্ট" />
            <div className="h-full bg-emerald-500 w-[5%]" title="অ্যাপস" />
          </div>
        </div>

        {/* Search & Actions Bar */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-col sm:flex-row items-center gap-2">
          <div className="relative flex-1 w-full flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={localQuery}
              onChange={(e) => setLocalQuery(e.target.value)}
              placeholder="ফাইলের নাম বা এক্সটেনশন দিয়ে খুঁজুন (যেমন .pdf, .mp4)..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder-slate-500 outline-none"
            />
          </div>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleRealFileUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shrink-0 shadow-md"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>নতুন ফাইল যুক্ত করুন</span>
          </button>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 px-4 py-2 bg-slate-950/40 border-b border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'সব ফাইল' },
            { id: 'photo', label: 'ছবি (Photos)' },
            { id: 'video', label: 'ভিডিও (Videos)' },
            { id: 'audio', label: 'গান ও অডিও' },
            { id: 'document', label: 'ডকুমেন্ট ও PDF' },
            { id: 'apk', label: 'ডাউনলোড ও APK' },
          ].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setFilterCat(c.id)}
              className={`px-3 py-1 rounded-full text-[11px] font-medium whitespace-nowrap transition-all ${
                filterCat === c.id
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Files List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredFiles.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 space-y-2">
              <Folder className="w-8 h-8 text-slate-600 mx-auto" />
              <p>কোনো ফাইল পাওয়া যায়নি।</p>
            </div>
          ) : (
            filteredFiles.map((file) => (
              <div
                key={file.id}
                onClick={() => onPreviewFile(file)}
                className="p-3 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-400/40 transition-all flex items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-slate-800 text-slate-300 shrink-0 group-hover:scale-105 transition-transform">
                    {file.category === 'photo' && <ImageIcon className="w-4 h-4 text-pink-400" />}
                    {file.category === 'video' && <Film className="w-4 h-4 text-indigo-400" />}
                    {file.category === 'audio' && <Music className="w-4 h-4 text-purple-400" />}
                    {file.category === 'document' && <FileText className="w-4 h-4 text-amber-400" />}
                    {file.category === 'apk' && <Download className="w-4 h-4 text-emerald-400" />}
                  </div>

                  <div className="min-w-0">
                    <h4 className="text-xs font-semibold text-slate-200 truncate group-hover:text-amber-300">
                      {file.name}
                    </h4>
                    <p className="text-[10px] text-slate-400 truncate">{file.path}</p>
                    <div className="flex items-center gap-2 text-[9px] text-slate-500 mt-0.5">
                      <span>{file.size}</span>
                      <span>·</span>
                      <span>{file.updatedAt}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onPreviewFile(file);
                    }}
                    className="p-2 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                    title="প্রিভিউ দেখুন"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
