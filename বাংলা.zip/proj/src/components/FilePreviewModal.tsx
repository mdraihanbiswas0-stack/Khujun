import React from 'react';
import { X, Download, Share2, Eye, FileText, Image as ImageIcon, Music, Film } from 'lucide-react';
import { MobileFile } from '../types';

interface FilePreviewModalProps {
  file: MobileFile | null;
  onClose: () => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({ file, onClose }) => {
  if (!file) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className="p-2 rounded-xl bg-amber-400/20 text-amber-300 shrink-0">
              {file.category === 'photo' && <ImageIcon className="w-5 h-5 text-pink-400" />}
              {file.category === 'video' && <Film className="w-5 h-5 text-indigo-400" />}
              {file.category === 'audio' && <Music className="w-5 h-5 text-purple-400" />}
              {file.category === 'document' && <FileText className="w-5 h-5 text-amber-400" />}
              {file.category === 'apk' && <Download className="w-5 h-5 text-emerald-400" />}
            </span>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-100 truncate">{file.name}</h3>
              <p className="text-[11px] text-slate-400 truncate">{file.path}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Preview */}
        <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 flex flex-col items-center justify-center min-h-[180px] text-center space-y-3">
          {file.category === 'photo' ? (
            <div className="w-full aspect-video rounded-xl bg-slate-800/80 flex items-center justify-center text-slate-400 overflow-hidden relative">
              <ImageIcon className="w-12 h-12 text-pink-400/60" />
              <span className="absolute bottom-2 text-xs text-slate-300 bg-black/70 px-2 py-0.5 rounded">
                ফটো ভিউয়ার প্রিভিউ ({file.size})
              </span>
            </div>
          ) : file.category === 'audio' ? (
            <div className="w-full space-y-3 py-4">
              <div className="w-14 h-14 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center mx-auto animate-pulse">
                <Music className="w-7 h-7" />
              </div>
              <p className="text-xs font-semibold text-slate-200">{file.name}</p>
              {/* Synthetic visual audio bar */}
              <div className="flex items-center justify-center gap-1 h-6">
                {[12, 24, 18, 30, 16, 26, 14, 22, 10, 28].map((h, i) => (
                  <span
                    key={i}
                    className="w-1 bg-purple-400 rounded-full animate-pulse"
                    style={{ height: `${h}px`, animationDelay: `${i * 0.1}s` }}
                  />
                ))}
              </div>
            </div>
          ) : file.category === 'video' ? (
            <div className="w-full aspect-video rounded-xl bg-slate-800/80 flex flex-col items-center justify-center text-slate-400 space-y-2">
              <Film className="w-10 h-10 text-indigo-400" />
              <span className="text-xs text-slate-300">ভিডিও প্লেয়ার সিমুলেশন ({file.size})</span>
            </div>
          ) : (
            <div className="space-y-2 py-4">
              <FileText className="w-12 h-12 text-amber-400/80 mx-auto" />
              <h4 className="text-xs font-semibold text-slate-200">ডকুমেন্ট ভিউয়ার</h4>
              <p className="text-[11px] text-slate-400">সাইজ: {file.size} · আপডেটের তারিখ: {file.updatedAt}</p>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
          >
            বন্ধ করুন
          </button>
          <button
            type="button"
            onClick={() => {
              alert(`"${file.name}" ফাইলটি খোলা হয়েছে।`);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
          >
            ফাইল ওপেন করুন
          </button>
        </div>
      </div>
    </div>
  );
};
