import React, { useState } from 'react';
import {
  Smartphone,
  Wifi,
  Battery,
  Signal,
  Download,
  Info,
  ExternalLink,
  Sparkles,
  Layers,
  ArrowRight,
  Maximize2,
  Check,
} from 'lucide-react';
import { WidgetToolItem, WidgetStyleConfig, InstalledApp } from '../types';
import { JonakiWidget } from './JonakiWidget';

interface MobileHomeScreenSimulatorProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit: (q: string) => void;
  tools: WidgetToolItem[];
  styleConfig: WidgetStyleConfig;
  onToolClick: (toolActionId: string) => void;
  onOpenCustomizer: () => void;
  onOpenVoiceSearch: () => void;
  onOpenCameraSearch: () => void;
  installedApps: InstalledApp[];
  onOpenApkModal?: () => void;
}

const WALLPAPERS = [
  { id: 'biolum', name: 'জোনাকি অরণ্য', class: 'bg-gradient-to-b from-slate-950 via-emerald-950 to-slate-900' },
  { id: 'midnight', name: 'মিডনাইট অরোরা', class: 'bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-950' },
  { id: 'sunset', name: 'গোল্ডেন সানসেট', class: 'bg-gradient-to-b from-stone-950 via-amber-950 to-slate-950' },
  { id: 'cyber', name: 'সাইবার নিওন', class: 'bg-gradient-to-b from-slate-950 via-purple-950 to-slate-900' },
];

export const MobileHomeScreenSimulator: React.FC<MobileHomeScreenSimulatorProps> = ({
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  tools,
  styleConfig,
  onToolClick,
  onOpenCustomizer,
  onOpenVoiceSearch,
  onOpenCameraSearch,
  installedApps,
  onOpenApkModal,
}) => {
  const [activeWallpaper, setActiveWallpaper] = useState(WALLPAPERS[0]);
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  const handleInstallPWA = () => {
    // If deferredPrompt is available on window
    const deferredPrompt = (window as any).deferredPrompt;
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          setIsInstalled(true);
        }
      });
    } else {
      setShowInstallGuide(true);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Top Banner explaining Mobile Screen Widget Mode */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-400/20 text-amber-300 shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-100">
              মোবাইল স্ক্রিন লাইভ উইজেট সিমুলেটর
            </h3>
            <p className="text-xs text-slate-300">
              অ্যাপে না ঢুকেও সরাসরি আপনার মোবাইল স্ক্রিনের উইজেট বার থেকে যেকোনো কিছু সার্চ করুন
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenApkModal && (
            <button
              type="button"
              onClick={onOpenApkModal}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md transition-all whitespace-nowrap active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>APK ডাউনলোড ও ফরম্যাট</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleInstallPWA}
            className="px-3 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition-colors whitespace-nowrap"
          >
            <span>ফোনে সেট</span>
          </button>
          <button
            type="button"
            onClick={() => setShowInstallGuide(!showInstallGuide)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700"
            title="ইনস্টলেশন নির্দেশিকা"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Installation Guide Card */}
      {showInstallGuide && (
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 animate-in fade-in">
          <h4 className="text-xs font-bold text-amber-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            কীভাবে আপনার ফোনের হোম স্ক্রিনে জোনাকি উইজেট আনবেন:
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-300">
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">ধাপ ১: ব্রাউজার মেনু</span>
              ক্রোম বা মোবাইল ব্রাউজারের উপরে ডানদিকের তিনটি ডট (⋮) অপশনে চাপ দিন।
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">ধাপ ২: হোম স্ক্রিন</span>
              "Add to Home Screen" বা "Install App" অপশনটি সিলেক্ট করুন।
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="font-bold text-amber-400 block mb-1">ধাপ ৩: উইজেট সুবিধা</span>
              ফোনের স্ক্রিনে ট্যাপ করে ধরে রাখুন এবং জোনাকি শর্টকাট সরাসরি যুক্ত করুন।
            </div>
          </div>
        </div>
      )}

      {/* Wallpaper Switcher */}
      <div className="flex items-center justify-between text-xs px-2">
        <span className="text-slate-400 font-medium">মোবাইল স্ক্রিন ওয়ালপেপার:</span>
        <div className="flex items-center gap-1.5">
          {WALLPAPERS.map((wp) => (
            <button
              key={wp.id}
              type="button"
              onClick={() => setActiveWallpaper(wp)}
              className={`px-2.5 py-1 rounded-full text-[11px] transition-all ${
                activeWallpaper.id === wp.id
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {wp.name}
            </button>
          ))}
        </div>
      </div>

      {/* Simulated Smartphone Shell */}
      <div className="relative mx-auto w-full max-w-md rounded-[42px] p-3.5 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 shadow-2xl border-4 border-slate-700/80">
        {/* Device Outer Frame */}
        <div
          className={`relative w-full rounded-[34px] overflow-hidden min-h-[580px] sm:min-h-[640px] flex flex-col justify-between p-4 shadow-inner ${activeWallpaper.class}`}
        >
          {/* Subtle wallpaper bioluminescent particle glow */}
          <div className="absolute top-1/4 left-1/3 w-48 h-48 rounded-full bg-amber-400/10 blur-3xl pointer-events-none" />
          <div className="absolute bottom-1/3 right-1/4 w-40 h-40 rounded-full bg-emerald-400/10 blur-3xl pointer-events-none" />

          {/* Top Status Bar & Notch */}
          <div className="relative z-20 flex items-center justify-between text-white text-[11px] font-mono px-2 pt-1 pb-3">
            <span className="font-bold tracking-wider">১২:৪৫</span>
            {/* Dynamic Island / Speaker Pill */}
            <div className="w-20 h-4 bg-black rounded-full flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-slate-900" />
            </div>
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px]">৯৮%</span>
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Home Screen Body: Clock Widget + Prominent Jonaki Search Widget */}
          <div className="relative z-10 space-y-6 pt-2">
            {/* Bengali Clock & Date Widget */}
            <div className="text-center space-y-1 select-none">
              <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight drop-shadow-md">
                ১২:৪৫
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 font-medium drop-shadow">
                রবিবার · ৮ নভেম্বর ২০২৬ · কার্তিক ১৪৩৩
              </p>
            </div>

            {/* THE JONAKI SEARCH WIDGET (Prominently placed on Home Screen) */}
            <div className="w-full">
              <div className="text-[10px] text-amber-300 font-bold mb-1 px-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>জোনাকি মোবাইল উইজেট (Google Chrome স্টাইল)</span>
              </div>
              <JonakiWidget
                searchQuery={searchQuery}
                onSearchChange={onSearchChange}
                onSearchSubmit={onSearchSubmit}
                tools={tools}
                styleConfig={styleConfig}
                onToolClick={onToolClick}
                onOpenCustomizer={onOpenCustomizer}
                onOpenVoiceSearch={onOpenVoiceSearch}
                onOpenCameraSearch={onOpenCameraSearch}
                isCompact={true}
              />
            </div>
          </div>

          {/* Home Screen App Grid (Simulating real installed apps) */}
          <div className="relative z-10 space-y-3 pb-2 pt-8">
            <div className="grid grid-cols-4 gap-3 text-center">
              {installedApps.slice(0, 8).map((app) => (
                <button
                  key={app.id}
                  type="button"
                  onClick={() => onToolClick('apps')}
                  className="flex flex-col items-center gap-1 group active:scale-90 transition-transform"
                >
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:scale-105 transition-transform"
                    style={{ backgroundColor: app.iconBgColor }}
                  >
                    {app.name.charAt(0)}
                  </div>
                  <span className="text-[10px] font-semibold text-slate-200 truncate w-full drop-shadow">
                    {app.nameBn}
                  </span>
                </button>
              ))}
            </div>

            {/* Dock Bar at bottom */}
            <div className="p-2 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/10 flex items-center justify-around">
              {installedApps.slice(0, 4).map((app) => (
                <div
                  key={`dock-${app.id}`}
                  className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-bold text-sm shadow-md"
                  style={{ backgroundColor: app.iconBgColor }}
                >
                  {app.name.charAt(0)}
                </div>
              ))}
            </div>

            {/* Home gesture bar */}
            <div className="w-32 h-1 bg-white/60 rounded-full mx-auto mt-2" />
          </div>
        </div>
      </div>
    </div>
  );
};
