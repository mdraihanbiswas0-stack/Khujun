import React, { useState } from 'react';
import {
  X,
  Palette,
  Sliders,
  Check,
  RotateCcw,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Layers,
} from 'lucide-react';
import { WidgetToolItem, WidgetStyleConfig } from '../types';

interface WidgetCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tools: WidgetToolItem[];
  onUpdateTools: (tools: WidgetToolItem[]) => void;
  styleConfig: WidgetStyleConfig;
  onUpdateStyleConfig: (config: WidgetStyleConfig) => void;
  onResetDefaults: () => void;
}

const PRESET_COLORS = [
  '#ec4899', // Pink
  '#06b6d4', // Cyan
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#10b981', // Emerald
  '#3b82f6', // Blue
  '#ef4444', // Red
  '#14b8a6', // Teal
  '#a855f7', // Purple
  '#f97316', // Orange
  '#6366f1', // Indigo
  '#84cc16', // Lime
  '#0284c7', // Sky
  '#eab308', // Yellow
  '#d946ef', // Fuchsia
  '#ffffff', // White
];

export const WidgetCustomizerModal: React.FC<WidgetCustomizerModalProps> = ({
  isOpen,
  onClose,
  tools,
  onUpdateTools,
  styleConfig,
  onUpdateStyleConfig,
  onResetDefaults,
}) => {
  const [activeTab, setActiveTab] = useState<'tools' | 'theme'>('tools');
  const [selectedToolId, setSelectedToolId] = useState<string>(tools[0]?.id || '');

  if (!isOpen) return null;

  const handleToggleTool = (id: string) => {
    const updated = tools.map((t) => (t.id === id ? { ...t, enabled: !t.enabled } : t));
    onUpdateTools(updated);
  };

  const handleMoveTool = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= tools.length) return;
    const newTools = [...tools];
    const temp = newTools[index];
    newTools[index] = newTools[targetIndex];
    newTools[targetIndex] = temp;
    // update orders
    newTools.forEach((t, i) => (t.order = i + 1));
    onUpdateTools(newTools);
  };

  const handleUpdateToolColor = (id: string, color: string) => {
    const updated = tools.map((t) =>
      t.id === id
        ? {
            ...t,
            color,
            bgColor: `${color}25`,
          }
        : t
    );
    onUpdateTools(updated);
  };

  const selectedTool = tools.find((t) => t.id === selectedToolId) || tools[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
              <Palette className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                উইজেট ও টুলস কাস্টমাইজেশন
              </h3>
              <p className="text-[11px] text-slate-400">
                টুলস যোগ/বাদ দিন, প্রতিটি আইকনের আলাদা রং দিন এবং উইজেট ব্যাকগ্রাউন্ড সাজান
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center justify-center gap-2 p-2 bg-slate-950/60 border-b border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('tools')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'tools'
                ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>টুলস ও আইকন কালার ({tools.filter((t) => t.enabled).length}/{tools.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('theme')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'theme'
                ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>উইজেট ব্যাকগ্রাউন্ড ও স্টাইল</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'tools' ? (
            <div className="space-y-4">
              {/* Selected Tool Color Customizer */}
              {selectedTool && (
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: selectedTool.color }}
                      />
                      "{selectedTool.labelBn}" আইকনের কাস্টম কালার নির্বাচন করুন:
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {selectedTool.color}
                    </span>
                  </div>

                  {/* Palette Grid */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {PRESET_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => handleUpdateToolColor(selectedTool.id, c)}
                        className={`w-7 h-7 rounded-full transition-transform hover:scale-115 flex items-center justify-center border ${
                          selectedTool.color === c ? 'border-white scale-110 shadow-md' : 'border-slate-700'
                        }`}
                        style={{ backgroundColor: c }}
                      >
                        {selectedTool.color === c && (
                          <Check className="w-3.5 h-3.5 text-black drop-shadow" />
                        )}
                      </button>
                    ))}

                    {/* Custom HTML color picker */}
                    <div className="relative flex items-center">
                      <input
                        type="color"
                        value={selectedTool.color}
                        onChange={(e) => handleUpdateToolColor(selectedTool.id, e.target.value)}
                        className="w-7 h-7 rounded-full border border-slate-700 bg-transparent cursor-pointer"
                        title="নিজের পছন্দমতো কালার কোড বাছুন"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tools List with Add/Remove and Reorder */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-400 px-1 pb-1">
                  <span>উইজেটে উপস্থিত টুলস তালিকা</span>
                  <span>সক্রিয় / নিষ্ক্রিয়</span>
                </div>

                {tools.map((tool, index) => (
                  <div
                    key={tool.id}
                    onClick={() => setSelectedToolId(tool.id)}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                      selectedToolId === tool.id
                        ? 'bg-slate-800/90 border-amber-400/50'
                        : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border"
                        style={{
                          backgroundColor: tool.bgColor,
                          color: tool.color,
                          borderColor: `${tool.color}40`,
                        }}
                      >
                        ●
                      </span>
                      <div className="min-w-0">
                        <h4 className="text-xs font-semibold text-slate-100 truncate">
                          {tool.labelBn}
                        </h4>
                        <span className="text-[10px] text-slate-400">{tool.label}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Reorder Arrows */}
                      <button
                        type="button"
                        disabled={index === 0}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMoveTool(index, 'up');
                        }}
                        className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
                        title="উপরে নিন"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={index === tools.length - 1}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMoveTool(index, 'down');
                        }}
                        className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
                        title="নিচে নিন"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      {/* Enable/Disable Toggle Switch */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleTool(tool.id);
                        }}
                        className={`w-9 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
                          tool.enabled ? 'bg-amber-400' : 'bg-slate-800'
                        }`}
                        title={tool.enabled ? 'টুলস বাদ দিন' : 'টুলস যোগ করুন'}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                            tool.enabled ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Theme & Background Customization */
            <div className="space-y-4">
              {/* Preset Themes */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">
                  উইজেট ব্যাকগ্রাউন্ড থিম নির্বাচন করুন:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'dark', label: 'ডিপ ডার্ক (Dark Slate)', bg: 'from-slate-900 to-slate-950' },
                    { id: 'emerald', label: 'বায়োলুমিনেসেন্ট এমারেল্ড', bg: 'from-emerald-950 to-teal-950' },
                    { id: 'amber', label: 'গোল্ডেন সানসেট', bg: 'from-amber-950 to-stone-900' },
                    { id: 'oled', label: 'রয়্যাল ওলেড ব্ল্যাক', bg: 'from-black to-zinc-950' },
                    { id: 'ocean', label: 'ওশান সায়ান', bg: 'from-cyan-950 to-blue-950' },
                    { id: 'custom', label: 'কাস্টম কালার প্যালেট', bg: 'from-purple-950 to-indigo-950' },
                  ].map((theme) => (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() =>
                        onUpdateStyleConfig({
                          ...styleConfig,
                          theme: theme.id as any,
                        })
                      }
                      className={`p-3 rounded-xl border text-left bg-gradient-to-r ${theme.bg} transition-all ${
                        styleConfig.theme === theme.id
                          ? 'border-amber-400 shadow-md ring-1 ring-amber-400'
                          : 'border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-xs font-semibold text-slate-100 block truncate">
                        {theme.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom BG Color Picker */}
              {styleConfig.theme === 'custom' && (
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <label className="text-xs font-bold text-slate-300">
                    পছন্দসই ব্যাকগ্রাউন্ড কালার নির্বাচন:
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={styleConfig.customBgColor.startsWith('#') ? styleConfig.customBgColor : '#1e1b4b'}
                      onChange={(e) =>
                        onUpdateStyleConfig({
                          ...styleConfig,
                          customBgColor: e.target.value,
                        })
                      }
                      className="w-10 h-10 rounded-xl border border-slate-700 bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={styleConfig.customBgColor}
                      onChange={(e) =>
                        onUpdateStyleConfig({
                          ...styleConfig,
                          customBgColor: e.target.value,
                        })
                      }
                      className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-100 outline-none"
                      placeholder="e.g. #1e1b4b or rgba(...)"
                    />
                  </div>
                </div>
              )}

              {/* Border Radius */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">
                  উইজেট কোণ/শেপ (Border Radius):
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'full', label: 'ক্রোম পিল (Full)' },
                    { id: '2xl', label: 'সফট স্কয়ারকল' },
                    { id: 'xl', label: 'মডার্ন কার্ভ' },
                    { id: 'lg', label: 'কমপ্যাক্ট' },
                  ].map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() =>
                        onUpdateStyleConfig({
                          ...styleConfig,
                          borderRadius: r.id as any,
                        })
                      }
                      className={`p-2.5 rounded-xl border text-xs font-medium text-center transition-all ${
                        styleConfig.borderRadius === r.id
                          ? 'bg-amber-400 text-slate-950 font-bold border-amber-400'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Glow Intensity */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">
                  জোনাকি গ্লো উজ্জ্বলতা (Bioluminescent Aura):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'vibrant', label: 'উজ্জ্বল আলো (Vibrant)' },
                    { id: 'subtle', label: 'হালকা আভা (Subtle)' },
                    { id: 'none', label: 'বন্ধ (None)' },
                  ].map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() =>
                        onUpdateStyleConfig({
                          ...styleConfig,
                          glowIntensity: g.id as any,
                        })
                      }
                      className={`p-2 rounded-xl border text-xs font-medium text-center transition-all ${
                        styleConfig.glowIntensity === g.id
                          ? 'bg-amber-400 text-slate-950 font-bold border-amber-400'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300">জোনাকি অ্যানিমেটেড মাসকট প্রদর্শন</span>
                  <input
                    type="checkbox"
                    checked={styleConfig.showMascot}
                    onChange={(e) =>
                      onUpdateStyleConfig({ ...styleConfig, showMascot: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-amber-400 focus:ring-amber-400"
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300">সরাসরি ক্যামেরা বাটন উইজেটে রাখুন</span>
                  <input
                    type="checkbox"
                    checked={styleConfig.showCamera}
                    onChange={(e) =>
                      onUpdateStyleConfig({ ...styleConfig, showCamera: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-pink-400 focus:ring-pink-400"
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300">সরাসরি ভয়েস বাটন উইজেটে রাখুন</span>
                  <input
                    type="checkbox"
                    checked={styleConfig.showVoice}
                    onChange={(e) =>
                      onUpdateStyleConfig({ ...styleConfig, showVoice: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-cyan-400 focus:ring-cyan-400"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 flex items-center justify-between bg-slate-950/70">
          <button
            type="button"
            onClick={onResetDefaults}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-amber-400 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>ডিফল্ট রিস্টোর</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md transition-colors"
          >
            সংরক্ষণ ও বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
