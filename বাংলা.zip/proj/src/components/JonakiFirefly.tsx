import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';

interface JonakiFireflyProps {
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showSpeechBubble?: boolean;
  onTap?: () => void;
  className?: string;
  interactive?: boolean;
}

const JONAKI_SPEECHES = [
  'বলুন কিভাবে সাহায্য করতে পারি?',
  'কী সার্চ করতে চান আজ?',
  'ফাইল, ছবি, অ্যাপ নাকি অনলাইনে খুঁজবেন?',
  'ক্যামেরা দিয়ে ছবি বা QR স্ক্যান করুন!',
  'আমি আপনার ব্যক্তিগত সার্চ সহকারী জোনাকি!',
  'টুলসের কালার পরিবর্তন করতে স্টাইলারে যান!',
  'নাম লিখলে সব তথ্য একসাথে চলে আসবে!',
];

export const JonakiFirefly: React.FC<JonakiFireflyProps> = ({
  size = 'md',
  showSpeechBubble = true,
  onTap,
  className = '',
  interactive = true,
}) => {
  const [isExcited, setIsExcited] = useState(false);
  const [speechText, setSpeechText] = useState('বলুন কিভাবে সাহায্য করতে পারি?');
  const [bubbleVisible, setBubbleVisible] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const speechIndexRef = useRef(0);
  const dismissTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Play pleasant harmonic synth chime on tap
  const playChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.32);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.33);
    } catch {}
  };

  // Speak text using Web Speech API if enabled
  const speakText = (text: string) => {
    if (!soundEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'bn-BD';
      utterance.rate = 1.05;
      utterance.pitch = 1.15;
      window.speechSynthesis.speak(utterance);
    } catch {}
  };

  const handleFireflyClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsExcited(true);
    playChime();

    // Fire golden-yellow & lime bioluminescent sparkles around firefly
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      particleCount: 18,
      spread: 50,
      startVelocity: 16,
      origin: { x, y },
      colors: ['#facc15', '#bef264', '#38bdf8', '#fb7185'],
      disableForReducedMotion: true,
    });

    // Advance speech
    speechIndexRef.current = (speechIndexRef.current + 1) % JONAKI_SPEECHES.length;
    const nextSpeech = JONAKI_SPEECHES[speechIndexRef.current];
    setSpeechText(nextSpeech);
    setBubbleVisible(true);
    speakText(nextSpeech);

    // Auto-dismiss after 3.5s
    if (dismissTimerRef.current) clearTimeout(dismissTimerRef.current);
    dismissTimerRef.current = setTimeout(() => {
      setBubbleVisible(false);
    }, 3500);

    setTimeout(() => {
      setIsExcited(false);
    }, 900);

    if (onTap) onTap();
  };

  // Autonomous excited micro-flutter every 14 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.45) {
        setIsExcited(true);
        setTimeout(() => setIsExcited(false), 800);
      }
    }, 14000);

    return () => {
      clearInterval(interval);
      if (dismissTimerRef.current) clearTimeout(dismissTimerRef.current);
    };
  }, []);

  // Size dimensions:
  // 'md' is the primary size inside the widget (~34px x 34px, comfortable and beautiful)
  const sizeConfig = {
    sm: { box: 'w-7 h-7', scale: 0.95 },
    md: { box: 'w-9 h-9', scale: 1.15 },
    lg: { box: 'w-12 h-12', scale: 1.5 },
    hero: { box: 'w-16 h-16', scale: 2.0 },
  }[size] || { box: 'w-9 h-9', scale: 1.15 };

  const FireflyGraphic = (
    <div className="relative flex items-center justify-center animate-float-jonaki">
      {/* Bioluminescent Warm Phosphor Glow Halo */}
      <div
        className={`absolute inset-0 rounded-full bg-gradient-to-r from-amber-400/30 via-lime-400/25 to-yellow-400/30 blur-sm transition-all duration-300 pointer-events-none ${
          isExcited ? 'opacity-100 scale-125 bg-amber-300/50' : 'opacity-70 group-hover:opacity-100'
        }`}
      />

      {/* SVG Firefly Illustration */}
      <svg
        width="34"
        height="36"
        viewBox="0 0 36 38"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`transition-transform duration-300 pointer-events-none ${
          isExcited ? 'scale-115 rotate-6' : 'hover:scale-105'
        }`}
        style={{ transform: `scale(${sizeConfig.scale})` }}
      >
        <defs>
          {/* Glowing Abdomen Radial Gradient */}
          <radialGradient id="jonakiLantern" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="25%" stopColor="#fef08a" stopOpacity="0.95" />
            <stop offset="65%" stopColor="#bef264" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#65a30d" stopOpacity="0.4" />
          </radialGradient>

          {/* Translucent iridescent flight wings */}
          <linearGradient id="innerWingLeft" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.85" />
            <stop offset="50%" stopColor="#f472b6" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#fde047" stopOpacity="0.8" />
          </linearGradient>

          <linearGradient id="innerWingRight" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#f472b6" stopOpacity="0.85" />
            <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#bef264" stopOpacity="0.8" />
          </linearGradient>

          {/* Elytra (protective wing case) */}
          <linearGradient id="elytraLeft" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#475569" />
            <stop offset="35%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#090d16" />
          </linearGradient>
          <linearGradient id="elytraRight" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#475569" />
            <stop offset="35%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#090d16" />
          </linearGradient>
        </defs>

        {/* Antennae with golden bobbing tip */}
        <g className="animate-antenna" style={{ transformOrigin: '18px 8px' }}>
          <path
            d="M15 7 C13 3, 9 2, 7 3.5"
            stroke="#facc15"
            strokeWidth="1"
            strokeLinecap="round"
          />
          <circle cx="7" cy="3.5" r="0.8" fill="#fef08a" />

          <path
            d="M21 7 C23 3, 27 2, 29 3.5"
            stroke="#facc15"
            strokeWidth="1"
            strokeLinecap="round"
          />
          <circle cx="29" cy="3.5" r="0.8" fill="#fef08a" />
        </g>

        {/* Head & Big Sparkly Compound Eyes */}
        <ellipse cx="18" cy="8.5" rx="4" ry="3" fill="#0f172a" stroke="#334155" strokeWidth="0.7" />
        <circle cx="15.5" cy="8.2" r="1.3" fill="#38bdf8" />
        <circle cx="20.5" cy="8.2" r="1.3" fill="#38bdf8" />
        {/* Eye reflections */}
        <circle cx="15.8" cy="7.8" r="0.5" fill="#ffffff" />
        <circle cx="20.8" cy="7.8" r="0.5" fill="#ffffff" />

        {/* Pronotum with characteristic warm amber spots */}
        <path
          d="M12 10.5 C12 9, 24 9, 24 10.5 C25 13, 24 15.5, 18 15.5 C12 15.5, 11 13, 12 10.5 Z"
          fill="#1e293b"
          stroke="#475569"
          strokeWidth="0.7"
        />
        <ellipse cx="13.8" cy="12" rx="1.3" ry="1.6" fill="#f97316" fillOpacity="0.95" />
        <ellipse cx="22.2" cy="12" rx="1.3" ry="1.6" fill="#f97316" fillOpacity="0.95" />

        {/* Flight Wings (Fluttering membranous inner wings) */}
        <g
          className={isExcited ? 'animate-flutter-left' : 'group-hover:animate-flutter-left'}
          style={{ transformOrigin: '17px 16px' }}
        >
          <path
            d="M17 16 C11 15, 3 18, 4 27 C6 30, 14 29, 17 21 Z"
            fill="url(#innerWingLeft)"
            stroke="#ffffff"
            strokeWidth="0.6"
            strokeOpacity="0.8"
          />
          <path d="M17 16 C12 21, 8 25, 5 28" stroke="#ffffff" strokeWidth="0.4" strokeOpacity="0.7" />
          <path d="M14 20 C10 23, 7 26, 6 28" stroke="#f472b6" strokeWidth="0.4" strokeOpacity="0.6" />
        </g>

        <g
          className={isExcited ? 'animate-flutter-right' : 'group-hover:animate-flutter-right'}
          style={{ transformOrigin: '19px 16px' }}
        >
          <path
            d="M19 16 C25 15, 33 18, 32 27 C30 30, 22 29, 19 21 Z"
            fill="url(#innerWingRight)"
            stroke="#ffffff"
            strokeWidth="0.6"
            strokeOpacity="0.8"
          />
          <path d="M19 16 C24 21, 28 25, 31 28" stroke="#ffffff" strokeWidth="0.4" strokeOpacity="0.7" />
          <path d="M22 20 C26 23, 29 26, 30 28" stroke="#38bdf8" strokeWidth="0.4" strokeOpacity="0.6" />
        </g>

        {/* Bioluminescent Lantern Abdomen (Glowing phosphor organ) */}
        <g>
          <ellipse cx="18" cy="19" rx="5" ry="4" fill="#1e293b" stroke="#334155" strokeWidth="0.6" />
          {/* Main glowing lantern bulb */}
          <ellipse
            cx="18"
            cy="26"
            rx="4.8"
            ry="6.5"
            fill="url(#jonakiLantern)"
            filter="drop-shadow(0 0 6px rgba(250, 204, 21, 0.95))"
            className="animate-glow-biolum"
          />
          {/* Segment rings */}
          <line x1="14.5" y1="23.5" x2="21.5" y2="23.5" stroke="#84cc16" strokeWidth="0.5" strokeOpacity="0.7" />
          <line x1="15" y1="27" x2="21" y2="27" stroke="#84cc16" strokeWidth="0.5" strokeOpacity="0.7" />
        </g>

        {/* Hard Elytra (Wing Cases parted in elegant V flight angle) */}
        <path
          d="M17.5 15.5 C15.5 15.5, 12 17.5, 11 23 C10 28.5, 13.5 30.5, 15 31 C16.5 29, 17.5 20, 17.5 15.5 Z"
          fill="url(#elytraLeft)"
          stroke="#475569"
          strokeWidth="0.6"
          style={{
            transformOrigin: '17.5px 15.5px',
            transform: isExcited ? 'rotate(-8deg)' : 'rotate(-3deg)',
            transition: 'transform 0.25s ease',
          }}
        />
        <path
          d="M18.5 15.5 C20.5 15.5, 24 17.5, 25 23 C26 28.5, 22.5 30.5, 21 31 C19.5 29, 18.5 20, 18.5 15.5 Z"
          fill="url(#elytraRight)"
          stroke="#475569"
          strokeWidth="0.6"
          style={{
            transformOrigin: '18.5px 15.5px',
            transform: isExcited ? 'rotate(8deg)' : 'rotate(3deg)',
            transition: 'transform 0.25s ease',
          }}
        />

        {/* Elytra high-gloss metallic sheen line */}
        <path d="M13.5 19 C13 23, 13.5 26.5, 14.5 29" stroke="#94a3b8" strokeWidth="0.5" strokeOpacity="0.6" />
        <path d="M22.5 19 C23 23, 22.5 26.5, 21.5 29" stroke="#94a3b8" strokeWidth="0.5" strokeOpacity="0.6" />
      </svg>
    </div>
  );

  return (
    <div className={`relative inline-flex items-center justify-center select-none shrink-0 ${className}`}>
      {/* Speech Bubble Tooltip */}
      {showSpeechBubble && bubbleVisible && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute -top-15 left-1/2 -translate-x-1/2 z-50 min-w-[200px] max-w-[250px] bg-slate-900/95 text-amber-200 text-xs px-3.5 py-1.5 rounded-xl shadow-2xl border border-amber-400/50 backdrop-blur-md animate-in fade-in zoom-in-95 pointer-events-auto"
        >
          <div className="flex items-center justify-between gap-1 mb-0.5">
            <span className="flex items-center gap-1 text-[10.5px] font-bold text-amber-400">
              <Sparkles className="w-3 h-3 text-amber-300 animate-spin" style={{ animationDuration: '4s' }} />
              জোনাকি বলছে
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  const newState = !soundEnabled;
                  setSoundEnabled(newState);
                  if (newState) speakText(speechText);
                }}
                className="p-0.5 text-slate-400 hover:text-amber-300 transition-colors"
                title={soundEnabled ? 'ভয়েস বন্ধ' : 'ভয়েস চালু'}
              >
                {soundEnabled ? <Volume2 className="w-3 h-3 text-amber-400" /> : <VolumeX className="w-3 h-3" />}
              </button>
              <button
                type="button"
                onClick={() => setBubbleVisible(false)}
                className="text-[10px] text-slate-400 hover:text-white px-0.5"
              >
                ✕
              </button>
            </div>
          </div>
          <p className="text-[11px] leading-tight text-slate-100">{speechText}</p>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 border-b border-r border-amber-400/50 transform rotate-45" />
        </div>
      )}

      {/* Mascot Element */}
      {interactive ? (
        <button
          type="button"
          onClick={handleFireflyClick}
          aria-label="জোনাকি মাসকট - ট্যাপ করুন"
          className={`relative ${sizeConfig.box} flex items-center justify-center cursor-pointer transition-transform duration-200 active:scale-95 group focus:outline-none`}
          title="জোনাকি (ট্যাপ করে টিপস ও কথা শুনুন)"
        >
          {FireflyGraphic}
        </button>
      ) : (
        <div className={`relative ${sizeConfig.box} flex items-center justify-center pointer-events-none`}>
          {FireflyGraphic}
        </div>
      )}
    </div>
  );
};
