import { Settings as SettingsIcon } from 'lucide-react';
import React, { useRef, useState } from 'react';
import {
  Search,
  Mic,
  Camera,
  X,
  ChevronLeft,
  ChevronRight,
  Folder,
  Grid,
  Users,
  Globe,
  PlaySquare,
  BookOpen,
  Music,
  Image as ImageIcon,
  Film,
  ClipboardCopy,
  Calculator,
  FileText,
  Palette,
  SlidersHorizontal,
} from 'lucide-react';
import { WidgetToolItem, WidgetStyleConfig } from '../types';
import { JonakiFirefly } from './JonakiFirefly';

interface JonakiWidgetProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit: (q: string) => void;
  tools: WidgetToolItem[];
  styleConfig: WidgetStyleConfig;
  onToolClick: (toolActionId: string) => void;
  onOpenCustomizer: () => void;
  onOpenVoiceSearch: () => void;
  onOpenCameraSearch: () => void;
  isCompact?: boolean;
}

// Icon component lookup map
const ICON_MAP: Record<string, React.ElementType> = {
  Settings: SettingsIcon,
  Camera,
  Mic,
  Folder,
  Grid,
  Users,
  Globe,
  PlaySquare,
  BookOpen,
  Music,
  Image: ImageIcon,
  Film,
  ClipboardCopy,
  Calculator,
  FileText,
  Palette,
};

export const JonakiWidget: React.FC<JonakiWidgetProps> = ({
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  tools,
  styleConfig,
  onToolClick,
  onOpenCustomizer,
  onOpenVoiceSearch,
  onOpenCameraSearch,
  isCompact = false,
}) => {
  const toolsScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Check scroll positions
  const handleScroll = () => {
    if (!toolsScrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = toolsScrollRef.current;
    setCanScrollLeft(scrollLeft > 6);
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 6);
  };

  const scrollTools = (direction: 'left' | 'right') => {
    if (!toolsScrollRef.current) return;
    const distance = 140;
    toolsScrollRef.current.scrollBy({
      left: direction === 'left' ? -distance : distance,
      behavior: 'smooth',
    });
  };

  // Get dynamic styles based on styleConfig
  const getBackgroundStyle = () => {
    switch (styleConfig.theme) {
      case 'emerald':
        return 'bg-gradient-to-b from-emerald-950/90 to-slate-950/90 border-emerald-500/40 shadow-[0_8px_25px_rgba(16,185,129,0.2)]';
      case 'amber':
        return 'bg-gradient-to-b from-amber-950/90 to-slate-950/90 border-amber-500/40 shadow-[0_8px_25px_rgba(245,158,11,0.2)]';
      case 'oled':
        return 'bg-black/95 border-slate-800 shadow-[0_8px_28px_rgba(0,0,0,0.85)]';
      case 'ocean':
        return 'bg-gradient-to-b from-cyan-950/90 to-slate-950/90 border-cyan-500/40 shadow-[0_8px_25px_rgba(6,182,212,0.2)]';
      case 'custom':
        return '';
      case 'glass':
      case 'dark':
      default:
        return 'bg-slate-900/90 border-slate-700/60 shadow-[0_8px_30px_rgba(0,0,0,0.5)]';
    }
  };

  const getRadiusClass = () => {
    switch (styleConfig.borderRadius) {
      case 'full':
        return 'rounded-3xl';
      case '2xl':
        return 'rounded-2xl';
      case 'xl':
        return 'rounded-xl';
      case 'lg':
        return 'rounded-lg';
      default:
        return 'rounded-2xl';
    }
  };

  const enabledTools = tools.filter((t) => t.enabled).sort((a, b) => a.order - b.order);

  return (
    <div className="w-full relative group/widget">
      {/* Bioluminescent Outer Glow */}
      {styleConfig.glowIntensity !== 'none' && (
        <div
          className={`absolute -inset-0.5 ${getRadiusClass()} blur-lg opacity-40 transition-opacity duration-300 pointer-events-none ${
            styleConfig.glowIntensity === 'vibrant'
              ? 'bg-gradient-to-r from-amber-500/35 via-yellow-400/25 to-emerald-500/35 opacity-60'
              : 'bg-amber-400/15'
          }`}
        />
      )}

      {/* Main Slim Unified Chrome Widget Container (Strictly enclosed, zero overflow) */}
      <div
        style={{
          backdropFilter: `blur(${styleConfig.blurLevel}px)`,
          ...(styleConfig.theme === 'custom'
            ? {
                backgroundColor: styleConfig.customBgColor,
                borderColor: 'rgba(255,255,255,0.15)',
              }
            : {}),
        }}
        className={`relative z-10 w-full border backdrop-blur-md transition-all duration-300 overflow-hidden ${getBackgroundStyle()} ${getRadiusClass()}`}
      >
        {/* ROW 1: Ultra-Slim Search Bar Pill (Height ~46px) with Jonaki on the Left */}
        <div className="h-11 sm:h-12 px-2.5 sm:px-3 flex items-center gap-2 border-b border-slate-800/60 bg-slate-900/50">
          {/* Jonaki Firefly Mascot (Slightly larger, beautiful animation, sits comfortably inside) */}
          {styleConfig.showMascot && (
            <div className="shrink-0 flex items-center justify-center pr-0.5">
              <JonakiFirefly size={isCompact ? 'sm' : 'md'} />
            </div>
          )}

          {/* Search Icon & Text Field */}
          <div className="flex-1 relative flex items-center min-w-0">
            <Search className="w-4 h-4 text-amber-400/80 shrink-0 mr-2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  onSearchSubmit(searchQuery);
                }
              }}
              placeholder="মোবাইলের ফাইল, অ্যাপস, কন্টাক্ট বা অনলাইনে খুঁজুন..."
              className="w-full bg-transparent text-xs sm:text-sm text-slate-100 placeholder-slate-400/80 outline-none truncate pr-2 font-normal"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors shrink-0 mr-1"
                title="মুছে ফেলুন"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Direct Camera Button */}
          {styleConfig.showCamera && (
            <button
              type="button"
              onClick={onOpenCameraSearch}
              title="ক্যামেরা ও QR সার্চ"
              className="p-1.5 rounded-full bg-pink-500/15 text-pink-400 hover:bg-pink-500/25 active:scale-95 transition-all shrink-0 border border-pink-500/30 group"
            >
              <Camera className="w-3.5 h-3.5 transition-transform group-hover:scale-110" />
            </button>
          )}

          {/* Direct Voice Search Button */}
          {styleConfig.showVoice && (
            <button
              type="button"
              onClick={onOpenVoiceSearch}
              title="ভয়েস সার্চ"
              className="p-1.5 rounded-full bg-cyan-500/15 text-cyan-400 hover:bg-cyan-500/25 active:scale-95 transition-all shrink-0 border border-cyan-500/30 group"
            >
              <Mic className="w-3.5 h-3.5 transition-transform group-hover:scale-110" />
            </button>
          )}
        </div>

        {/* ROW 2: Slim Integrated Tools Dock (Inside Widget, Horizontal Scrolling, Icon + Name Underneath) */}
        <div className="relative py-1.5 px-2 bg-slate-950/40 flex items-center">
          {/* Scroll Left Button */}
          {canScrollLeft && (
            <button
              type="button"
              onClick={() => scrollTools('left')}
              className="absolute left-1 z-20 w-5 h-5 rounded-full bg-slate-900/95 text-slate-300 hover:text-white border border-slate-700 shadow-md flex items-center justify-center transition-all"
              title="বামে স্ক্রোল করুন"
            >
              <ChevronLeft className="w-3 h-3" />
            </button>
          )}

          {/* Tools Horizontal Strip (Strictly contained inside widget boundaries) */}
          <div
            ref={toolsScrollRef}
            onScroll={handleScroll}
            className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar scroll-smooth w-full px-1 py-0.5"
          >
            {enabledTools.map((tool) => {
              const IconComp = ICON_MAP[tool.iconName] || Folder;
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => onToolClick(tool.actionId)}
                  className="flex flex-col items-center justify-center py-0.5 px-1 shrink-0 group focus:outline-none transition-transform hover:scale-105 active:scale-95 min-w-[46px] max-w-[54px]"
                  title={`${tool.labelBn} (${tool.label})`}
                >
                  {/* Round Icon Badge */}
                  <div
                    className="w-7 h-7 sm:w-7.5 sm:h-7.5 rounded-full flex items-center justify-center shadow-xs transition-transform group-hover:scale-110"
                    style={{
                      backgroundColor: tool.bgColor,
                      color: tool.color,
                      border: `1px solid ${tool.color}40`,
                    }}
                  >
                    <IconComp className="w-3.5 h-3.5" style={{ color: tool.color }} />
                  </div>
                  {/* Small Name Underneath Icon */}
                  <span className="text-[9px] font-medium leading-tight mt-1 text-center truncate w-full text-slate-300 group-hover:text-amber-300">
                    {tool.labelBn}
                  </span>
                </button>
              );
            })}

            {/* Customize Trigger Button pinned inside the strip */}
            <button
              type="button"
              onClick={onOpenCustomizer}
              className="flex flex-col items-center justify-center py-0.5 px-1 shrink-0 group focus:outline-none transition-transform hover:scale-105 active:scale-95 min-w-[46px] max-w-[54px]"
              title="টুলস ও উইজেট কাস্টমাইজ করুন (রং, টুলস যোগ/বাদ)"
            >
              <div className="w-7 h-7 sm:w-7.5 sm:h-7.5 rounded-full bg-slate-800/90 border border-amber-400/40 text-amber-300 flex items-center justify-center shadow-xs transition-transform group-hover:scale-110">
                <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <span className="text-[9px] font-medium leading-tight mt-1 text-center text-amber-300 truncate w-full">
                কাস্টমাইজ
              </span>
            </button>
          </div>

          {/* Scroll Right Button */}
          {canScrollRight && (
            <button
              type="button"
              onClick={() => scrollTools('right')}
              className="absolute right-1 z-20 w-5 h-5 rounded-full bg-slate-900/95 text-slate-300 hover:text-white border border-slate-700 shadow-md flex items-center justify-center transition-all"
              title="ডানে স্ক্রোল করুন"
            >
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
