import { isNative } from '../plugins/deviceSearch';
import { pickDeviceContacts } from '../utils/androidIntent';
import React, { useState } from 'react';
import {
  Users,
  Phone,
  MessageSquare,
  Plus,
  X,
  Search,
  Copy,
  Check,
  Send,
  UserPlus,
} from 'lucide-react';
import { ContactItem } from '../types';

interface ContactsManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: ContactItem[];
  onAddContact: (newContact: ContactItem) => void;
}

export const ContactsManagerModal: React.FC<ContactsManagerModalProps> = ({
  isOpen,
  onClose,
  contacts,
  onAddContact,
}) => {
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRelation, setNewRelation] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    const colors = ['#2563eb', '#16a34a', '#db2777', '#7c3aed', '#d97706', '#0891b2', '#ea580c'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const created: ContactItem = {
      id: `contact-${Date.now()}`,
      name: newName.trim(),
      phone: newPhone.trim(),
      relationship: newRelation.trim() || 'পরিচিত',
      avatarColor: randomColor,
    };

    onAddContact(created);
    setNewName('');
    setNewPhone('');
    setNewRelation('');
    setShowAddForm(false);
  };

  const importFromPhone = async () => {
    try {
      const list = await pickDeviceContacts();
      if (list === null) {
        alert('ফোনের কন্টাক্ট আনতে অ্যান্ড্রয়েডের Chrome ব্রাউজার (HTTPS লিংক) দরকার।');
        return;
      }
      const colors = ['#2563eb', '#16a34a', '#db2777', '#7c3aed', '#d97706', '#0891b2', '#ea580c'];
      list.forEach((c, i) =>
        onAddContact({
          id: `device-${Date.now()}-${i}`,
          name: c.name,
          phone: c.phone,
          email: c.email,
          relationship: 'ফোনবুক',
          avatarColor: colors[i % colors.length],
        }),
      );
    } catch {
      /* user cancelled */
    }
  };

  const copyNumber = (num: string, id: string) => {
    navigator.clipboard.writeText(num);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filtered = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      (c.relationship && c.relationship.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Users className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                মোবাইল কন্টাক্ট ডিরেক্টরি
              </h3>
              <p className="text-[11px] text-slate-400">
                সকল ফোন নম্বর, সম্পর্ক এবং সরাসরি কল/মেসেজ পাঠানোর সুবিধা
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Add Action */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center gap-2">
          <div className="relative flex-1 flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder-slate-500 outline-none"
            />
          </div>
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 shrink-0 transition-colors"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>নতুন কন্টাক্ট</span>
          </button>
          {!isNative && (
          <button
            type="button"
            onClick={importFromPhone}
            className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shrink-0 transition-colors"
          >
            ফোন থেকে আনুন
          </button>
          )}
        </div>

        {/* Add Contact Form */}
        {showAddForm && (
          <form
            onSubmit={handleCreateContact}
            className="p-4 bg-slate-950/90 border-b border-slate-800 space-y-3 animate-in fade-in"
          >
            <h4 className="text-xs font-bold text-emerald-400">নতুন কন্টাক্ট যুক্ত করুন:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="পুরো নাম"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 placeholder-slate-500 outline-none"
              />
              <input
                type="text"
                placeholder="মোবাইল নম্বর (যেমন 017...)"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                required
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 placeholder-slate-500 outline-none"
              />
              <input
                type="text"
                placeholder="সম্পর্ক (বন্ধু / সহকর্মী)"
                value={newRelation}
                onChange={(e) => setNewRelation(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-100 placeholder-slate-500 outline-none"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1 text-xs text-slate-400 hover:text-white"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-4 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs"
              >
                সেভ করুন
              </button>
            </div>
          </form>
        )}

        {/* Contacts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              কোনো কন্টাক্ট পাওয়া যায়নি।
            </div>
          ) : (
            filtered.map((contact) => (
              <div
                key={contact.id}
                className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/40 transition-all flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-md"
                    style={{ backgroundColor: contact.avatarColor }}
                  >
                    {contact.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-semibold text-slate-100 truncate">
                      {contact.name}
                    </h4>
                    <p className="text-xs text-emerald-400 font-mono tracking-wide mt-0.5">
                      {contact.phone}
                    </p>
                    {contact.relationship && (
                      <span className="text-[10px] text-slate-500">{contact.relationship}</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <a
                    href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`}
                    className="p-2 rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 transition-colors"
                    title="কল করুন"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={`sms:${contact.phone.replace(/[^0-9]/g, '')}`}
                    className="p-2 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/25 transition-colors"
                    title="মেসেজ"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={`https://wa.me/${contact.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-green-500/15 text-green-400 hover:bg-green-500/25 transition-colors"
                    title="হোয়াটসঅ্যাপ"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </a>
                  <button
                    type="button"
                    onClick={() => copyNumber(contact.phone, contact.id)}
                    className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
                    title="কপি করুন"
                  >
                    {copiedId === contact.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
