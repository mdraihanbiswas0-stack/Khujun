import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  FileCode,
  Sparkles,
  X,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [activeTab, setActiveTab] = useState<'instant' | 'pwabuilder' | 'gradle' | 'zip'>('instant');

  const currentAppUrl = typeof window !== 'undefined' ? window.location.origin : '';

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallWebAPK = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      alert('আপনার ক্রোম ব্রাউজারের উপরে ডানদিকের তিনটি ডটে (⋮) চাপ দিয়ে "Add to Home Screen" বা "Install App" সিলেক্ট করুন। অ্যান্ড্রয়েড স্বয়ংক্রিয়ভাবে এটি WebAPK হিসেবে ইনস্টল করবে!');
    }
  };

  const downloadFile = (filename: string, content: string, type = 'application/xml') => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const androidManifestContent = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.jonaki.search">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="জোনাকি সার্চ"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="জোনাকি সার্চ"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const buildGradleContent = `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.jonaki.search'
    compileSdk 34

    defaultConfig {
        applicationId "com.jonaki.search"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'androidx.browser:browser:1.8.0'
}`;

  const capacitorConfigContent = `{
  "appId": "com.jonaki.search",
  "appName": "জোনাকি সার্চ",
  "webDir": "dist",
  "server": {
    "url": "${currentAppUrl}",
    "cleartext": true
  }
}`;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-amber-400/20 text-amber-300">
              <Smartphone className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
                <span>অ্যান্ড্রয়েড APK ফরম্যাট ও ইনস্টলার হাব</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">
                  APK READY
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                আপনার অ্যাপকে সরাসরি অ্যান্ড্রয়েড ফোনে APK হিসেবে ইনস্টল বা রূপান্তর করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center justify-center gap-1.5 p-2 bg-slate-950/60 border-b border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('instant')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'instant'
                ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>পদ্ধতি ১: WebAPK</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pwabuilder')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'pwabuilder'
                ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>পদ্ধতি ২: PWABuilder APK</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('gradle')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              activeTab === 'gradle'
                ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>পদ্ধতি ৩: কনফিগ</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('zip' as any)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              (activeTab as any) === 'zip'
                ? 'bg-emerald-400 text-slate-950 shadow-md font-bold'
                : 'text-emerald-400 hover:text-white border border-emerald-500/40'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>পদ্ধতি ৪: গিটহাব ZIP ফাইল</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === 'instant' && (
            <div className="space-y-4">
              {/* Highlight Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
                    <h4 className="text-sm font-bold text-emerald-300">
                      অ্যান্ড্রয়েড নেটিভ WebAPK সাপোর্ট সক্রিয় আছে
                    </h4>
                  </div>
                  {isInstalled && (
                    <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/40">
                      <CheckCircle2 className="w-3.5 h-3.5" /> ইনস্টল সম্পন্ন
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  বর্তমান অ্যান্ড্রয়েড সিস্টেমে গুগল ক্রোম স্বয়ংক্রিয়ভাবে একটি স্বাক্ষরিত (Signed) <strong>WebAPK</strong> তৈরি করে সরাসরি আপনার মোবাইলে ইনস্টল করে দেয়। এতে আলাদা করে কোনো জটিল অ্যান্ড্রয়েড স্টুডিও প্রয়োজন হয় না!
                </p>

                <button
                  type="button"
                  onClick={handleInstallWebAPK}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>এখনই ১-ক্লিকে ফোনে APK হিসেবে ইনস্টল করুন</span>
                </button>
              </div>

              {/* 3 Step Instruction */}
              <div className="space-y-2">
                <h5 className="text-xs font-bold text-slate-300">কীভাবে এটি কাজ করে:</h5>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-amber-400 font-bold">০১. ম্যানিফেস্ট লোড</span>
                    <p className="text-[11px] text-slate-400">
                      আমরা ইতিমধ্যেই <code>manifest.json</code>, আইকন এবং সার্ভিস ওয়ার্কার কনফিগার করে দিয়েছি।
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-amber-400 font-bold">০২. ক্রোম ইঞ্জিন প্যাকেজিং</span>
                    <p className="text-[11px] text-slate-400">
                      ইনস্টল বাটনে চাপ দিলে অ্যান্ড্রয়েড ব্যাকগ্রাউন্ডে আসল APK প্যাকেজ তৈরি করে।
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-amber-400 font-bold">০৩. হোম স্ক্রিন অ্যাপ</span>
                    <p className="text-[11px] text-slate-400">
                      অন্যান্য সব সাধারণ অ্যাপের মতো জোনাকি আপনার অ্যাপ ড্রয়ারে যুক্ত হয়ে যাবে।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'pwabuilder' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950/40 via-slate-900 to-slate-950 border border-blue-500/30 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <h4 className="text-sm font-bold text-blue-300">
                    মাইক্রোসফট PWABuilder দিয়ে সরাসরি .APK ফাইল ডাউনলোড
                  </h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  PWABuilder হলো মাইক্রোসফটের অফিসিয়াল টুল যা যেকোনো পিডাব্লিউএ-কে ১ ক্লিকে ইনস্টলেবল <code>.apk</code> বা গুগল প্লে স্টোরের <code>.aab</code> ফাইলে কনভার্ট করে দেয়।
                </p>

                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <span className="text-[11px] font-mono text-slate-300 truncate">
                    {currentAppUrl}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(currentAppUrl);
                      setCopiedScript(true);
                      setTimeout(() => setCopiedScript(false), 2000);
                    }}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs flex items-center gap-1 shrink-0"
                  >
                    {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>লিঙ্ক কপি</span>
                  </button>
                </div>

                <a
                  href={`https://www.pwabuilder.com/publish?site=${encodeURIComponent(currentAppUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-md"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>PWABuilder-এ যান এবং ১-ক্লিকে APK ডাউনলোড করুন</span>
                </a>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs text-slate-300">
                <span className="font-bold text-amber-400 block">ধাপগুলো:</span>
                <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px]">
                  <li>উপরের বাটনে চাপ দিয়ে PWABuilder ওয়েবসাইটে যান।</li>
                  <li>তারা আপনার অ্যাপের স্কোর ও ম্যানিফেস্ট স্বয়ংক্রিয়ভাবে স্ক্যান করে নিবে।</li>
                  <li><strong>"Package for Android"</strong> বাটনে চাপ দিলেই সরাসরি ডাউনলোড হয়ে যাবে রেডিমেড <code>.apk</code> ফাইল!</li>
                  <li>সেই APK ফাইলটি আপনার যেকোনো অ্যান্ড্রয়েড ফোনে ব্লুটুথ, শেয়ারইট বা গুগল ড্রাইভ দিয়ে ট্রান্সফার করে ইনস্টল করে নিতে পারবেন।</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'gradle' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                যদি আপনি নিজে <strong>Android Studio</strong> বা <strong>Capacitor</strong> দিয়ে APK বিল্ড করতে চান, নিচের রেডিমেড কনফিগারেশন ফাইলগুলো সরাসরি ডাউনলোড করে নিন:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-2">
                  <div>
                    <span className="text-xs font-bold text-slate-200 block truncate">
                      AndroidManifest.xml
                    </span>
                    <span className="text-[10px] text-slate-500">পারমিশন ও প্যাকেজ কনফিগ</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadFile('AndroidManifest.xml', androidManifestContent)}
                    className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ডাউনলোড</span>
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-2">
                  <div>
                    <span className="text-xs font-bold text-slate-200 block truncate">
                      build.gradle
                    </span>
                    <span className="text-[10px] text-slate-500">Gradle APK বিল্ডার স্ক্রিপ্ট</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadFile('build.gradle', buildGradleContent, 'text/plain')}
                    className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ডাউনলোড</span>
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-2">
                  <div>
                    <span className="text-xs font-bold text-slate-200 block truncate">
                      capacitor.config.json
                    </span>
                    <span className="text-[10px] text-slate-500">Capacitor APK ব্রিজ</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadFile('capacitor.config.json', capacitorConfigContent, 'application/json')}
                    className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ডাউনলোড</span>
                  </button>
                </div>
              </div>

              {/* Quick CLI command */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <span className="text-[11px] font-bold text-amber-400 block">
                  Capacitor দিয়ে ১ মিনিটে APK বানানোর কমান্ড:
                </span>
                <pre className="p-2.5 rounded-lg bg-black text-[11px] font-mono text-emerald-400 overflow-x-auto">
                  npm install @capacitor/core @capacitor/cli @capacitor/android{'\n'}
                  npx cap init "Jonaki Search" "com.jonaki.search"{'\n'}
                  npm run build{'\n'}
                  npx cap add android{'\n'}
                  npx cap open android
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'zip' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300">
                      <Layers className="w-4 h-4" />
                    </span>
                    <h4 className="text-sm font-bold text-emerald-300">
                      সম্পূর্ণ সোর্স কোড ZIP প্যাকেজ (GitHub ও APK প্রস্তুত)
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    ZIP READY
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  অ্যাপটির সকল ফ্রন্টএন্ড ও ব্যাকএন্ড ফাইল, কনফিগারেশন, অ্যান্ড্রয়েড ম্যানিফেস্ট এবং বিল্ড স্ক্রিপ্ট একত্রিত করে <strong>jonaki-search-app.zip</strong> প্যাকেজ তৈরি করা হয়েছে। আপনি সরাসরি ডাউনলোড করে GitHub-এ আপলোড করতে পারবেন এবং সম্পূর্ণ APK বিল্ড করতে পারবেন।
                </p>

                <a
                  href="/jonaki-search-app.zip"
                  download="jonaki-search-app.zip"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20 active:scale-98"
                >
                  <Download className="w-4 h-4" />
                  <span>jonaki-search-app.zip ডাউনলোড করুন (সরাসরি ব্রাউজারে)</span>
                </a>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs text-slate-300">
                <span className="font-bold text-amber-400 block">গিটহাব ও লোকাল বিল্ড করার সহজ নিয়ম:</span>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-400 text-[11px]">
                  <li>উপরের বাটনে চাপ দিয়ে <code>jonaki-search-app.zip</code> ফাইলটি আপনার কম্পিউটারে বা মোবাইলে ডাউনলোড করুন।</li>
                  <li>ফাইলটি আনজিপ (Extract) করুন।</li>
                  <li>টার্মিনালে প্রজেক্ট ফোল্ডারে ঢুকে টাইপ করুন: <code className="text-emerald-400">npm install</code></li>
                  <li>লোকালে টেস্ট করতে রান করুন: <code className="text-emerald-400">npm run dev</code></li>
                  <li>গিটহাবে আপলোড করতে:
                    <pre className="mt-1 p-2 rounded bg-black text-[10px] text-amber-300 font-mono">
                      git init{'\n'}
                      git add .{'\n'}
                      git commit -m "Initial commit for Jonaki Search"{'\n'}
                      git branch -M main{'\n'}
                      git remote add origin https://github.com/আপনার_ইউজারনেম/jonaki-search.git{'\n'}
                      git push -u origin main
                    </pre>
                  </li>
                  <li>অ্যান্ড্রয়েড APK বিল্ডের জন্য README.md ফাইলে দেয়া ৩টি সহজ কমান্ড অনুসরণ করুন।</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            অ্যান্ড্রয়েড ৫.০ থেকে ১৫+ সব ভার্সনে সাপোর্টেড
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
