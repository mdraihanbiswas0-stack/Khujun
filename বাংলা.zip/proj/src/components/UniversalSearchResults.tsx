import React, { useState } from 'react';
import {
  FileText,
  Image as ImageIcon,
  Film,
  Music,
  Folder,
  Download,
  Phone,
  MessageSquare,
  Share2,
  ExternalLink,
  Play,
  Copy,
  Check,
  Sparkles,
  BookOpen,
  ArrowRight,
  Eye,
  Send,
} from 'lucide-react';
import {
  MobileFile,
  InstalledApp,
  ContactItem,
  QuranSurah,
  AiSearchResult,
  SearchCategory,
} from '../types';
import { SettingsSearchSection } from './SettingsSearchSection';
import { ANDROID_SETTINGS, searchSettings } from '../data/androidSettings';

interface UniversalSearchResultsProps {
  query: string;
  categoryFilter: SearchCategory;
  onCategoryFilterChange: (cat: SearchCategory) => void;
  files: MobileFile[];
  apps: InstalledApp[];
  contacts: ContactItem[];
  quranRefs: QuranSurah[];
  aiResult: AiSearchResult | null;
  isLoadingAi: boolean;
  onPreviewFile: (file: MobileFile) => void;
  onLaunchApp: (app: InstalledApp) => void;
}

export const UniversalSearchResults: React.FC<UniversalSearchResultsProps> = ({
  query,
  categoryFilter,
  onCategoryFilterChange,
  files,
  apps,
  contacts,
  quranRefs,
  aiResult,
  isLoadingAi,
  onPreviewFile,
  onLaunchApp,
}) => {
  const [copiedContactId, setCopiedContactId] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedContactId(id);
    setTimeout(() => setCopiedContactId(null), 2000);
  };

  const getFileIcon = (cat: MobileFile['category']) => {
    switch (cat) {
      case 'photo':
        return <ImageIcon className="w-5 h-5 text-pink-400" />;
      case 'video':
        return <Film className="w-5 h-5 text-indigo-400" />;
      case 'audio':
        return <Music className="w-5 h-5 text-purple-400" />;
      case 'document':
        return <FileText className="w-5 h-5 text-amber-400" />;
      case 'apk':
        return <Download className="w-5 h-5 text-emerald-400" />;
      default:
        return <Folder className="w-5 h-5 text-slate-400" />;
    }
  };

  // Step Category Tabs
  const steps: Array<{ id: SearchCategory; label: string; count: number; color: string }> = [
    { id: 'all', label: 'সব ধাপ (All)', count: files.length + apps.length + contacts.length + quranRefs.length, color: 'text-amber-400' },
    { id: 'files', label: '📁 ফাইল ও স্টোরেজ', count: files.length, color: 'text-amber-400' },
    { id: 'apps', label: '📱 ইনস্টলড অ্যাপস', count: apps.length, color: 'text-violet-400' },
    { id: 'settings', label: '⚙️ সেটিংস', count: searchSettings(query).length, color: 'text-cyan-400' },
    { id: 'contacts', label: '👥 কন্টাক্ট লিস্ট', count: contacts.length, color: 'text-emerald-400' },
    { id: 'youtube', label: '▶️ ইউটিউব', count: 3, color: 'text-red-400' },
    { id: 'web', label: '🌐 অনলাইন ও ক্রোম', count: 3, color: 'text-blue-400' },
    { id: 'quran', label: '📖 কুরআন ও হাদিস', count: quranRefs.length, color: 'text-teal-400' },
    { id: 'ai', label: '✨ এআই অন্তর্দৃষ্টি', count: aiResult ? 1 : 0, color: 'text-yellow-300' },
  ];

  const totalResults = files.length + apps.length + contacts.length + quranRefs.length;

  return (
    <div className="w-full space-y-6">
      {/* Category / Step Filter Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        {steps.map((step) => {
          const isActive = categoryFilter === step.id;
          return (
            <button
              key={step.id}
              type="button"
              onClick={() => onCategoryFilterChange(step.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-400/20'
                  : 'bg-slate-900/80 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>{step.label}</span>
              {step.count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-slate-900 text-amber-300' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {step.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Query Header with Stepped Source Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80 text-xs text-slate-400">
        <div>
          <span>অনুসন্ধান ফলাফল: </span>
          <span className="text-amber-300 font-semibold text-sm">"{query || 'সবকিছু'}"</span>
          <span className="text-slate-500 ml-2">({totalResults} টি আইটেম পাওয়া গেছে)</span>
        </div>
        <div className="text-[11px] text-slate-400 bg-slate-900/60 px-2.5 py-1 rounded-full border border-slate-800 w-fit">
          ধাপে ধাপে সোর্স ভিত্তিক ফলাফল সাজানো হয়েছে
        </div>
      </div>

      {/* AI Smart Summary Card (Powered by Gemini) */}
      {(categoryFilter === 'all' || categoryFilter === 'ai') && (
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-amber-950/40 via-slate-900/90 to-slate-950/90 border border-amber-500/30 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-400/20 text-amber-300">
                <Sparkles className="w-4 h-4 animate-spin" style={{ animationDuration: '6s' }} />
              </span>
              <h3 className="text-sm font-bold text-amber-300 tracking-wide">
                ধাপ ১: জোনাকি এআই স্মার্ট উত্তর ও সামারি
              </h3>
            </div>
            {isLoadingAi && (
              <span className="text-xs text-amber-400 animate-pulse">
                বিশ্লেষণ করা হচ্ছে...
              </span>
            )}
          </div>

          {isLoadingAi ? (
            <div className="space-y-2 py-2">
              <div className="h-4 bg-slate-800/80 rounded-md w-3/4 animate-pulse" />
              <div className="h-4 bg-slate-800/80 rounded-md w-1/2 animate-pulse" />
            </div>
          ) : aiResult ? (
            <div className="space-y-3">
              <p className="text-sm sm:text-base text-slate-100 leading-relaxed font-normal">
                {aiResult.summary}
              </p>

              {aiResult.keyFacts && aiResult.keyFacts.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-800/60">
                  {aiResult.keyFacts.map((fact, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2"
                    >
                      <span className="text-amber-400 font-bold">0{idx + 1}.</span>
                      <span>{fact}</span>
                    </div>
                  ))}
                </div>
              )}

              {aiResult.quranReference && (
                <div className="p-3 rounded-xl bg-teal-950/40 border border-teal-500/30 text-xs text-teal-200">
                  <span className="font-bold text-teal-300">📖 ইসলামিক রেফারেন্স: </span>
                  {aiResult.quranReference}
                </div>
              )}
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              সার্চ বোতামে চাপ দিলে যেকোনো বিষয়ের তাৎক্ষণিক স্মার্ট বিশ্লেষণ জোনাকি প্রদান করবে।
            </p>
          )}
        </div>
      )}

      {/* STEP 2: Mobile Storage & Files */}
      {(categoryFilter === 'all' || categoryFilter === 'files') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              ধাপ ২: মোবাইল ফাইল ও স্টোরেজ ({files.length} টি)
            </h3>
            <span className="text-xs text-slate-500">Internal Storage / SD Card</span>
          </div>

          {files.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400 text-center">
              মোবাইলের ফাইলে এই নামে কোনো ফাইল পাওয়া যায়নি।
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {files.map((file) => (
                <div
                  key={file.id}
                  onClick={() => onPreviewFile(file)}
                  className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-850 border border-slate-800 hover:border-amber-400/30 transition-all flex items-center justify-between gap-3 cursor-pointer group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/50 shrink-0 group-hover:scale-105 transition-transform">
                      {getFileIcon(file.category)}
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-semibold text-slate-100 truncate group-hover:text-amber-300 transition-colors">
                        {file.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {file.path}
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500">
                        <span>{file.size}</span>
                        <span>·</span>
                        <span>{file.updatedAt}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onPreviewFile(file);
                    }}
                    className="p-2 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors shrink-0"
                    title="প্রিভিউ ও খুলুন"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* STEP 3: Installed Apps & Downloaded APKs */}
      {(categoryFilter === 'all' || categoryFilter === 'apps') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-violet-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-violet-400" />
              ধাপ ৩: ইনস্টল করা মোবাইল অ্যাপস ({apps.length} টি)
            </h3>
            <span className="text-xs text-slate-500">Installed Applications</span>
          </div>

          {apps.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400 text-center">
              এই নামে কোনো ইনস্টলড অ্যাপ পাওয়া যায়নি।
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {apps.map((app) => (
                <div
                  key={app.id}
                  onClick={() => onLaunchApp(app)}
                  className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-850 border border-slate-800 hover:border-violet-500/40 transition-all flex items-center gap-3 cursor-pointer group"
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-base shadow-md shrink-0 group-hover:scale-105 transition-transform"
                    style={{ backgroundColor: app.iconBgColor }}
                  >
                    {app.iconDataUrl ? (
                      <img src={app.iconDataUrl} alt="" className="w-full h-full rounded-xl object-cover" />
                    ) : (
                      app.name.charAt(0)
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-semibold text-slate-100 truncate group-hover:text-violet-300 transition-colors">
                      {app.nameBn}
                    </h4>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">{app.name}</p>
                    <span className="text-[9px] text-slate-500">{app.size}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* STEP 4: Mobile Phonebook & Contacts List */}
      {(categoryFilter === 'all' || categoryFilter === 'settings') && (
        <SettingsSearchSection query={query} />
      )}

      {(categoryFilter === 'all' || categoryFilter === 'contacts') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              ধাপ ৪: মোবাইল ফোনবুক কন্টাক্ট ({contacts.length} জন)
            </h3>
            <span className="text-xs text-slate-500">Phone & SIM Contacts</span>
          </div>

          {contacts.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400 text-center">
              কন্টাক্ট লিস্টে কোনো তথ্য খুঁজে পাওয়া যায়নি।
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-emerald-500/30 transition-all flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                      style={{ backgroundColor: contact.avatarColor }}
                    >
                      {contact.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-semibold text-slate-100 truncate">
                        {contact.name}
                      </h4>
                      <p className="text-xs text-emerald-400 font-mono tracking-wide mt-0.5">
                        {contact.phone}
                      </p>
                      {contact.relationship && (
                        <span className="text-[10px] text-slate-500">{contact.relationship}</span>
                      )}
                    </div>
                  </div>

                  {/* Contact Action Buttons */}
                  <div className="flex items-center gap-1 shrink-0">
                    <a
                      href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`}
                      className="p-2 rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 transition-colors"
                      title="কল করুন"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </a>
                    <a
                      href={`sms:${contact.phone.replace(/[^0-9]/g, '')}`}
                      className="p-2 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/25 transition-colors"
                      title="মেসেজ পাঠান"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                    </a>
                    <a
                      href={`https://wa.me/${contact.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-green-500/15 text-green-400 hover:bg-green-500/25 transition-colors"
                      title="হোয়াটসঅ্যাপে চ্যাট"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </a>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(contact.phone, contact.id)}
                      className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
                      title="নম্বর কপি করুন"
                    >
                      {copiedContactId === contact.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* STEP 5: YouTube & Video Content */}
      {(categoryFilter === 'all' || categoryFilter === 'youtube') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-red-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-400" />
              ধাপ ৫: ইউটিউব ভিডিও ফলাফল
            </h3>
            <span className="text-xs text-slate-500">YouTube Stream & Shorts</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              {
                title: `${query || 'জনপ্রিয়'} সম্পর্কিত সেরা বাংলা ভিডিও টিউটোরিয়াল`,
                channel: 'Jonaki Tech BD',
                views: '১২৪K views',
                duration: '10:45',
              },
              {
                title: `${query || 'মোবাইল'} ফুল রিভিউ ও বিস্তারিত গাইড ২০২৬`,
                channel: 'Bangla Review Hub',
                views: '৮৯K views',
                duration: '14:20',
              },
              {
                title: `${query || 'নতুন খবর'} আজকের আপডেট ও বিশ্লেষণ`,
                channel: 'News & Media Bangla',
                views: '২.১M views',
                duration: '06:12',
              },
            ].map((video, idx) => (
              <a
                key={idx}
                href={`https://www.youtube.com/results?search_query=${encodeURIComponent(query || 'Bangla')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-850 border border-slate-800 hover:border-red-500/40 transition-all block group"
              >
                <div className="relative aspect-video rounded-lg bg-slate-800 flex items-center justify-center overflow-hidden mb-2">
                  <Play className="w-8 h-8 text-red-500/80 group-hover:scale-110 group-hover:text-red-400 transition-all" />
                  <span className="absolute bottom-1 right-1 text-[9px] bg-black/80 text-white px-1 rounded font-mono">
                    {video.duration}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-slate-100 group-hover:text-red-300 transition-colors line-clamp-2">
                  {video.title}
                </h4>
                <div className="flex items-center justify-between mt-1 text-[10px] text-slate-500">
                  <span>{video.channel}</span>
                  <span>{video.views}</span>
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {/* STEP 6: Online Chrome / Web & Social Search */}
      {(categoryFilter === 'all' || categoryFilter === 'web') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-blue-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              ধাপ ৬: অনলাইন, ক্রোম ও সোশ্যাল মিডিয়া
            </h3>
            <span className="text-xs text-slate-500">Google, Facebook, TikTok</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              {
                name: 'গুগল সার্চ',
                url: `https://www.google.com/search?q=${encodeURIComponent(query || 'Bangladesh')}`,
                color: 'text-blue-400',
                border: 'hover:border-blue-500/40',
              },
              {
                name: 'ফেসবুক সার্চ',
                url: `https://www.facebook.com/search/top/?q=${encodeURIComponent(query || 'Bangladesh')}`,
                color: 'text-indigo-400',
                border: 'hover:border-indigo-500/40',
              },
              {
                name: 'টিকটক ভিডিও',
                url: `https://www.tiktok.com/search?q=${encodeURIComponent(query || 'Bangladesh')}`,
                color: 'text-pink-400',
                border: 'hover:border-pink-500/40',
              },
              {
                name: 'উইকিপিডিয়া বাংলা',
                url: `https://bn.wikipedia.org/wiki/${encodeURIComponent(query || 'বাংলাদেশ')}`,
                color: 'text-slate-300',
                border: 'hover:border-slate-500/40',
              },
            ].map((portal, idx) => (
              <a
                key={idx}
                href={portal.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-xl bg-slate-900/70 border border-slate-800 ${portal.border} flex items-center justify-between transition-all group`}
              >
                <span className={`text-xs font-semibold ${portal.color}`}>
                  {portal.name}
                </span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors" />
              </a>
            ))}
          </div>
        </section>
      )}

      {/* STEP 7: Quran & Islamic Knowledge Reference */}
      {(categoryFilter === 'all' || categoryFilter === 'quran') && quranRefs.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-teal-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-teal-400" />
              ধাপ ৭: কুরআন ও ইসলামিক রেফারেন্স ({quranRefs.length} টি সূরা)
            </h3>
            <span className="text-xs text-slate-500">Holy Quran Insights</span>
          </div>

          <div className="space-y-2.5">
            {quranRefs.map((surah) => (
              <div
                key={surah.number}
                className="p-4 rounded-xl bg-slate-900/70 border border-teal-900/50 hover:border-teal-500/40 transition-all space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold flex items-center justify-center font-mono">
                      {surah.number}
                    </span>
                    <h4 className="text-sm font-bold text-slate-100">
                      {surah.nameBengali} ({surah.nameArabic})
                    </h4>
                    <span className="text-[11px] text-teal-400">· {surah.revelationType}</span>
                  </div>
                  <span className="text-xs text-slate-500">{surah.versesCount} টি আয়াত</span>
                </div>

                {surah.popularAyat && (
                  <div className="p-3 rounded-lg bg-teal-950/30 border border-teal-900/40 space-y-1">
                    <p className="text-right text-base text-teal-200 font-serif leading-loose" dir="rtl">
                      {surah.popularAyat.arabic}
                    </p>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {surah.popularAyat.bengali}
                    </p>
                    <span className="text-[10px] text-teal-400 font-mono block text-right">
                      {surah.popularAyat.reference}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
